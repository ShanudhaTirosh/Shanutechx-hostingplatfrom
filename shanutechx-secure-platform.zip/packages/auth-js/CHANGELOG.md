## 2.110.7 (2026-07-16)

This was a version bump only for @supabase/auth-js to align it with other projects, there were no code changes.

## 2.110.6 (2026-07-15)

This was a version bump only for @supabase/auth-js to align it with other projects, there were no code changes.

## 2.110.5 (2026-07-14)

This was a version bump only for @supabase/auth-js to align it with other projects, there were no code changes.

## 2.110.4 (2026-07-14)

This was a version bump only for @supabase/auth-js to align it with other projects, there were no code changes.

## 2.110.3 (2026-07-13)

### 🩹 Fixes

- **auth:** preserve pkce verifier ([#2513](https://github.com/supabase/supabase-js/pull/2513))

### ❤️ Thank You

- Vaibhav @7ttp

## 2.110.2 (2026-07-09)

### 🩹 Fixes

- **auth:** clear local session on signout failures ([#2504](https://github.com/supabase/supabase-js/pull/2504))

### ❤️ Thank You

- Luc Peng

## 2.110.1 (2026-07-07)

### 🩹 Fixes

- **auth:** defer init-time notifications until initializePromise resolves ([#2498](https://github.com/supabase/supabase-js/pull/2498))

### ❤️ Thank You

- Katerina Skroumpelou @mandarini

## 2.110.0 (2026-06-30)

### 🚀 Features

- **repo:** drop Node.js 20 support ([#2482](https://github.com/supabase/supabase-js/pull/2482))

### ❤️ Thank You

- Katerina Skroumpelou @mandarini

## 2.109.0 (2026-06-30)

### 🚀 Features

- **auth:** add custom_claims_allowlist to custom providers admin API ([#2473](https://github.com/supabase/supabase-js/pull/2473))

### ❤️ Thank You

- Cemal Kılıç @cemalkilic
- Claude Opus 4.8 (1M context)

## 2.108.2 (2026-06-15)

### 🩹 Fixes

- **auth:** preserve valid session on refresh failure and cooldown repeat failures ([#2436](https://github.com/supabase/supabase-js/pull/2436))

### ❤️ Thank You

- Katerina Skroumpelou @mandarini

## 2.108.0 (2026-06-08)

### 🚀 Features

- **auth:** auth.resend() consistent confirmation flow ([#2144](https://github.com/supabase/supabase-js/pull/2144))

### 🩹 Fixes

- **auth:** do not console.error AuthApiError already returned through contract ([#2428](https://github.com/supabase/supabase-js/pull/2428))

### ❤️ Thank You

- Lawrence Li @weilirs
- MaitreyeeDeshmukh

## 2.107.0 (2026-06-02)

### 🚀 Features

- **auth:** remove navigator.locks-based mutex; introduce commit guard + dispose() ([#2392](https://github.com/supabase/supabase-js/pull/2392))

### 🩹 Fixes

- **auth): revert fix(auth:** encode client-id in oauth requests ([#2383](https://github.com/supabase/supabase-js/pull/2383), [#2417](https://github.com/supabase/supabase-js/pull/2417))
- **auth:** recognize ?error= redirects in implicit grant gate ([#2407](https://github.com/supabase/supabase-js/pull/2407))
- **auth:** return AuthInvalidJwtError from getClaims for expired JWT ([#2395](https://github.com/supabase/supabase-js/pull/2395))

### ❤️ Thank You

- Katerina Skroumpelou @mandarini
- Omar Al Matar @Bewinxed

## 2.106.2 (2026-05-25)

### 🩹 Fixes

- **auth:** restore signup user response ([#2391](https://github.com/supabase/supabase-js/pull/2391))

### ❤️ Thank You

- Vaibhav @7ttp

## 2.106.1 (2026-05-20)

### 🩹 Fixes

- **auth:** encode client-id in oauth requests ([#2383](https://github.com/supabase/supabase-js/pull/2383))

### ❤️ Thank You

- Etienne Stalmans @staaldraad

## 2.106.0 (2026-05-18)

### 🩹 Fixes

- **auth:** return null user and session for email_change single-confirmation verifyOtp ([#2378](https://github.com/supabase/supabase-js/pull/2378))

### ❤️ Thank You

- Katerina Skroumpelou @mandarini

## 2.105.4 (2026-05-08)

### 🩹 Fixes

- **auth:** return null from getItemAsync on JSON parse failure ([#2336](https://github.com/supabase/supabase-js/pull/2336))

## 2.105.2 (2026-05-04)

### 🩹 Fixes

- **auth:** add toJSON to WebAuthnError for correct JSON serialization ([#2317](https://github.com/supabase/supabase-js/pull/2317))
- **misc:** reduce any usage across packages ([#2314](https://github.com/supabase/supabase-js/pull/2314))
- **misc:** widen enum-like unions with (string & {}) for forward compat ([#2303](https://github.com/supabase/supabase-js/pull/2303))

## 2.105.1 (2026-04-28)

This was a version bump only for @supabase/auth-js to align it with other projects, there were no code changes.

## 2.105.0 (2026-04-27)

### 🚀 Features

- **auth:** add passkey support with WebAuthn registration, authentication, and management ([#2283](https://github.com/supabase/supabase-js/pull/2283))

## 2.104.1 (2026-04-23)

### 🩹 Fixes

- **auth:** emit PASSWORD_RECOVERY event for PKCE recovery flows ([#2272](https://github.com/supabase/supabase-js/pull/2272))

### ❤️ Thank You

- Katerina Skroumpelou @mandarini

## 2.104.0 (2026-04-20)

This was a version bump only for @supabase/auth-js to align it with other projects, there were no code changes.

## 2.103.3 (2026-04-16)

This was a version bump only for @supabase/auth-js to align it with other projects, there were no code changes.

## 2.103.2 (2026-04-15)

### 🩹 Fixes

- **misc:** add explicit return types to toJSON methods for JSR compat ([#2252](https://github.com/supabase/supabase-js/pull/2252))
- **auth:** remove Prettify wrapper from exported types for TypeDoc expansion ([#2250](https://github.com/supabase/supabase-js/pull/2250))
- **auth:** include Cloudflare error codes in NETWORK_ERROR_CODES ([#2239](https://github.com/supabase/supabase-js/pull/2239))

### ❤️ Thank You

- Katerina Skroumpelou @mandarini
- Vansh Sharma @Vansh1811

## 2.103.1 (2026-04-15)

### 🩹 Fixes

- **auth:** add toJSON to AuthError for correct JSON serialization ([#2238](https://github.com/supabase/supabase-js/pull/2238))

### ❤️ Thank You

- oniani1

## 2.103.0 (2026-04-09)

This was a version bump only for @supabase/auth-js to align it with other projects, there were no code changes.

## 2.102.1 (2026-04-07)

This was a version bump only for @supabase/auth-js to align it with other projects, there were no code changes.

## 2.102.0 (2026-04-07)

### 🩹 Fixes

- **auth:** downgrade console.error to console.warn for missing session ([#2214](https://github.com/supabase/supabase-js/pull/2214))

### ❤️ Thank You

- Katerina Skroumpelou @mandarini

## 2.101.1 (2026-03-31)

This was a version bump only for @supabase/auth-js to align it with other projects, there were no code changes.

## 2.101.0 (2026-03-30)

This was a version bump only for @supabase/auth-js to align it with other projects, there were no code changes.

## 2.100.1 (2026-03-26)

This was a version bump only for @supabase/auth-js to align it with other projects, there were no code changes.

## 2.100.0 (2026-03-23)

### 🩹 Fixes

- **auth:** guard navigator lock steal against cascade when lock is stolen by another request ([#2178](https://github.com/supabase/supabase-js/pull/2178))

### ❤️ Thank You

- Katerina Skroumpelou @mandarini

## 2.99.2 (2026-03-16)

This was a version bump only for @supabase/auth-js to align it with other projects, there were no code changes.

## 2.99.1 (2026-03-11)

This was a version bump only for @supabase/auth-js to align it with other projects, there were no code changes.

## 2.99.0 (2026-03-09)

### 🚀 Features

- **auth:** add custom OIDC/OAuth provider admin CRUD methods ([#2133](https://github.com/supabase/supabase-js/pull/2133))

### ❤️ Thank You

- Cemal Kılıç @cemalkilic

## 2.98.0 (2026-02-26)

### 🚀 Features

- **auth:** add currentPassword to UserAttributes type ([#2131](https://github.com/supabase/supabase-js/pull/2131))
- **auth:** support custom providers via `custom:` prefix in Provider type ([#2134](https://github.com/supabase/supabase-js/pull/2134))
- **auth:** add `token_endpoint_auth_method` to OAuth client create/update ([#2132](https://github.com/supabase/supabase-js/pull/2132))

### 🩹 Fixes

- **auth:** fixes userattributes type ([#2139](https://github.com/supabase/supabase-js/pull/2139))
- **auth:** lower lockAcquireTimeout default to 5s and fix stale JSDoc ([#2125](https://github.com/supabase/supabase-js/pull/2125))
- **auth:** recover from orphaned navigator locks via steal fallback ([#2106](https://github.com/supabase/supabase-js/pull/2106))

### ❤️ Thank You

- Cemal Kılıç @cemalkilic
- Elliot Padfield @ElliotPadfield
- Etienne Stalmans @staaldraad
- Katerina Skroumpelou @mandarini

## 2.97.0 (2026-02-18)

### 🚀 Features

- **auth:** add skipAutoInitialize option to prevent constructor auto-init ([#2123](https://github.com/supabase/supabase-js/pull/2123))

### ❤️ Thank You

- Katerina Skroumpelou @mandarini

## 2.96.0 (2026-02-17)

### 🩹 Fixes

- **auth:** resolve Firefox content script Promise.then() security errors in locks ([#2112](https://github.com/supabase/supabase-js/pull/2112))

### ❤️ Thank You

- Katerina Skroumpelou @mandarini

## 2.95.3 (2026-02-06)

This was a version bump only for @supabase/auth-js to align it with other projects, there were no code changes.

## 2.95.0 (2026-02-05)

This was a version bump only for @supabase/auth-js to align it with other projects, there were no code changes.

## 2.94.1 (2026-02-04)

### 🩹 Fixes

- **auth:** correct OAuth authorization types to match API responses ([#2088](https://github.com/supabase/supabase-js/pull/2088))

### ❤️ Thank You

- Katerina Skroumpelou @mandarini

## 2.94.0 (2026-02-03)

This was a version bump only for @supabase/auth-js to align it with other projects, there were no code changes.

## 2.93.3 (2026-01-29)

### 🩹 Fixes

- **auth:** add webauthn tests and fix fallback naming ([#1763](https://github.com/supabase/supabase-js/pull/1763))

### ❤️ Thank You

- Katerina Skroumpelou @mandarini

## 2.93.2 (2026-01-27)

This was a version bump only for @supabase/auth-js to align it with other projects, there were no code changes.

## 2.93.1 (2026-01-26)

This was a version bump only for @supabase/auth-js to align it with other projects, there were no code changes.

## 2.93.0 (2026-01-26)

### 🚀 Features

- **auth:** add optional jwt parameter to getAuthenticatorAssuranceLevel ([#1940](https://github.com/supabase/supabase-js/pull/1940))

### 🩹 Fixes

- **auth:** clear local storage on signOut when session is already missing ([#2026](https://github.com/supabase/supabase-js/pull/2026))
- **auth:** handle uncaught promise rejections during initialization ([#2032](https://github.com/supabase/supabase-js/pull/2032))

### ❤️ Thank You

- Vaibhav @7ttp

## 2.91.1 (2026-01-23)

### 🩹 Fixes

- **auth:** restore SSR OAuth functionality broken in v2.91.0 ([#2039](https://github.com/supabase/supabase-js/pull/2039))

### ❤️ Thank You

- Vaibhav @7ttp

## 2.91.0 (2026-01-20)

### 🩹 Fixes

- **auth:** clarify updateUserById applies changes directly ([#2031](https://github.com/supabase/supabase-js/pull/2031))
- **auth:** defer subscriber notification in exchangeCodeForSession to prevent deadlock ([#2014](https://github.com/supabase/supabase-js/pull/2014))

### ❤️ Thank You

- Vaibhav @7ttp

## 2.90.1 (2026-01-08)

This was a version bump only for @supabase/auth-js to align it with other projects, there were no code changes.

## 2.90.0 (2026-01-07)

### 🩹 Fixes

- **auth:** add configurable lock acquisition timeout to prevent deadlocks ([#1962](https://github.com/supabase/supabase-js/pull/1962))
- **auth:** preserve session when magic link is clicked twice ([#1996](https://github.com/supabase/supabase-js/pull/1996))
- **auth:** clear initial setTimeout in stopAutoRefresh ([#1993](https://github.com/supabase/supabase-js/pull/1993))
- **auth:** add last_challenged_at property to factor type ([#1990](https://github.com/supabase/supabase-js/pull/1990))
- **auth:** add banned_until property to user type ([#1989](https://github.com/supabase/supabase-js/pull/1989))

### ❤️ Thank You

- Vaibhav @7ttp
- yoshifumi kondo @yoshifumi-kondo

## 2.89.0 (2025-12-18)

### 🚀 Features

- **auth:** add string array support for AMR claims ([#1967](https://github.com/supabase/supabase-js/pull/1967))
- **auth:** add X (OAuth 2.0) provider ([#1960](https://github.com/supabase/supabase-js/pull/1960))

### ❤️ Thank You

- Cemal Kılıç @cemalkilic
- issuedat @issuedat

## 2.88.0 (2025-12-16)

### 🚀 Features

- **auth:** allow custom predicate for detectSessionInUrl option ([#1958](https://github.com/supabase/supabase-js/pull/1958))

### ❤️ Thank You

- Katerina Skroumpelou @mandarini

## 2.87.3 (2025-12-15)

This was a version bump only for @supabase/auth-js to align it with other projects, there were no code changes.

## 2.87.2 (2025-12-15)

### 🩹 Fixes

- **auth:** add helpful error when PKCE code verifier is missing ([#1931](https://github.com/supabase/supabase-js/pull/1931))

### ❤️ Thank You

- Katerina Skroumpelou @mandarini

## 2.87.1 (2025-12-09)

### 🩹 Fixes

- **auth:** skip navigator lock when persistSession is false ([#1928](https://github.com/supabase/supabase-js/pull/1928))

### ❤️ Thank You

- Vaibhav @7ttp

## 2.87.0 (2025-12-08)

This was a version bump only for @supabase/auth-js to align it with other projects, there were no code changes.

## 2.86.2 (2025-12-04)

This was a version bump only for @supabase/auth-js to align it with other projects, there were no code changes.

## 2.86.1 (2025-12-04)

### 🩹 Fixes

- **auth:** code verifier remains in storage during edge cases ([#1759](https://github.com/supabase/supabase-js/pull/1759))
- **auth:** suppress getsession warning when getuser is called first ([#1898](https://github.com/supabase/supabase-js/pull/1898))

### ❤️ Thank You

- Katerina Skroumpelou @mandarini
- Vaibhav @7ttp

## 2.86.0 (2025-11-26)

This was a version bump only for @supabase/auth-js to align it with other projects, there were no code changes.

## 2.85.0 (2025-11-26)

### 🩹 Fixes

- **auth:** oauth minor fixes on types ([#1891](https://github.com/supabase/supabase-js/pull/1891))

### ❤️ Thank You

- Cemal Kılıç @cemalkilic

## 2.84.0 (2025-11-20)

This was a version bump only for @supabase/auth-js to align it with other projects, there were no code changes.

## 2.83.0 (2025-11-18)

This was a version bump only for @supabase/auth-js to align it with other projects, there were no code changes.

## 2.82.0 (2025-11-18)

### 🚀 Features

- **auth:** add OAuth grant listing and revocation endpoints ([#1833](https://github.com/supabase/supabase-js/pull/1833))

### ❤️ Thank You

- Cemal Kılıç @cemalkilic

## 2.81.1 (2025-11-11)

### 🩹 Fixes

- **auth:** add automatic browser redirect to signInWithSSO ([#1849](https://github.com/supabase/supabase-js/pull/1849))
- **auth:** use Symbols for callback IDs to resolve Next.js 16 compatibility ([#1847](https://github.com/supabase/supabase-js/pull/1847))

### ❤️ Thank You

- Katerina Skroumpelou @mandarini

## 2.81.0 (2025-11-10)

### 🩹 Fixes

- **auth:** use direct attestation for registration/authentication ([#1764](https://github.com/supabase/supabase-js/pull/1764))
- **auth:** add providers type to UserAppMetadata interface ([#1760](https://github.com/supabase/supabase-js/pull/1760))
- **auth:** make webauthn param optional and move register params to webauthn ([#1765](https://github.com/supabase/supabase-js/pull/1765))

### ❤️ Thank You

- Katerina Skroumpelou @mandarini

## 2.80.0 (2025-11-06)

### 🚀 Features

- **auth:** add TypeScript types for documented JWT claims fields ([#1802](https://github.com/supabase/supabase-js/pull/1802))

### 🩹 Fixes

- **auth:** only warn if multiple clients share a storage-key ([#1767](https://github.com/supabase/supabase-js/pull/1767))

### ❤️ Thank You

- Steve Hall @sh41
- Sumit Kumar @Software-Engineering-Project-Team-Bob

## 2.79.0 (2025-11-04)

### 🚀 Features

- **repo:** remove node-fetch dependency, require Node.js 20+ ([#1830](https://github.com/supabase/supabase-js/pull/1830))
- **auth:** support throwing errors instead of returning them ([#1766](https://github.com/supabase/supabase-js/pull/1766))

### ❤️ Thank You

- Katerina Skroumpelou @mandarini

## 2.78.0 (2025-10-30)

### 🚀 Features

- **auth:** refactor getAuthenticatorAssuranceLevel method ([#1822](https://github.com/supabase/supabase-js/pull/1822))
- **auth:** add OAuth client update support ([#1812](https://github.com/supabase/supabase-js/pull/1812))
- **auth:** add OAuth 2.1 authorization consent management API calls ([#1793](https://github.com/supabase/supabase-js/pull/1793))

### 🩹 Fixes

- **auth:** move session warning proxy from session to user object ([#1817](https://github.com/supabase/supabase-js/pull/1817))
- **auth:** remove redirection in `getAuthorizationDetails` ([#1811](https://github.com/supabase/supabase-js/pull/1811))

### ❤️ Thank You

- Cemal Kılıç @cemalkilic
- Katerina Skroumpelou @mandarini
- Stojan Dimitrovski @hf

## v2.77.0 (2025-10-29)

### 🚀 Features

- **auth:** add OAuth client update support ([#1812](https://github.com/supabase/supabase-js/pull/1812))
- **auth:** add OAuth 2.1 authorization consent management API calls ([#1793](https://github.com/supabase/supabase-js/pull/1793))

### 🩹 Fixes

- **auth:** remove redirection in `getAuthorizationDetails` ([#1811](https://github.com/supabase/supabase-js/pull/1811))
- **auth:** handle 204 No Content response in OAuth client delete ([#1786](https://github.com/supabase/supabase-js/pull/1786))
- **repo:** add missing tslib dependency to core packages ([#1789](https://github.com/supabase/supabase-js/pull/1789))

### ❤️ Thank You

- Cemal Kılıç @cemalkilic
- Katerina Skroumpelou @mandarini

## 2.76.1 (2025-10-21)

### 🩹 Fixes

- **repo:** add missing tslib dependency to core packages ([#1789](https://github.com/supabase/supabase-js/pull/1789))

### ❤️ Thank You

- Katerina Skroumpelou @mandarini

## 2.76.0 (2025-10-20)

### 🚀 Features

- **storage:** storage vectors and analytics in storage-js ([#1752](https://github.com/supabase/supabase-js/pull/1752))

### 🩹 Fixes

- **repo:** convert postbuild to explicit codegen ([#1778](https://github.com/supabase/supabase-js/pull/1778))

### ❤️ Thank You

- Katerina Skroumpelou @mandarini

## 2.75.1 (2025-10-17)

This was a version bump only for @supabase/auth-js to align it with other projects, there were no code changes.

## 2.75.0 (2025-10-09)

This was a version bump only for @supabase/auth-js to align it with other projects, there were no code changes.

## 2.74.0 (2025-10-07)

### 🚀 Features

- **auth:** add OAuth 2.1 client admin endpoints ([#1582](https://github.com/supabase/supabase-js/pull/1582))
- **auth:** add deprecation notice to `onAuthStateChange` with async function ([#1580](https://github.com/supabase/supabase-js/pull/1580))

### ❤️ Thank You

- Cemal Kılıç @cemalkilic
- Stojan Dimitrovski @hf

# Changelog

## [2.72.0](https://github.com/supabase/auth-js/compare/v2.71.1...v2.72.0) (2025-09-11)

### Features

- add sign in with ethereum to `signInWithWeb3` ([#1082](https://github.com/supabase/auth-js/issues/1082)) ([483e24b](https://github.com/supabase/auth-js/commit/483e24be190f537eabdb85f8be2eee2b16797872))

### Bug Fixes

- correct typo in GoTrueClient initializePromise comment ([#1093](https://github.com/supabase/auth-js/issues/1093)) ([3a147b5](https://github.com/supabase/auth-js/commit/3a147b56e99565efde461cfe8463178dcd65ba43))
- docs for ethereum ([#1117](https://github.com/supabase/auth-js/issues/1117)) ([aadf02e](https://github.com/supabase/auth-js/commit/aadf02e63179746a06451f4247a370dfd05740ea))
- update typedoc to 0.23 ([#1113](https://github.com/supabase/auth-js/issues/1113)) ([91474d6](https://github.com/supabase/auth-js/commit/91474d642e077c9db41eb7c5d2387c9a4d3687cf))

## [2.71.1](https://github.com/supabase/auth-js/compare/v2.71.0...v2.71.1) (2025-07-17)

### Bug Fixes

- use JSON-based deep clone instead of structuredClone ([#1084](https://github.com/supabase/auth-js/issues/1084)) ([9a6edb9](https://github.com/supabase/auth-js/commit/9a6edb9d0e4d80c79c79b2f643dbaaf57f3d5ebe))

## [2.71.0](https://github.com/supabase/auth-js/compare/v2.70.0...v2.71.0) (2025-07-10)

### Features

- fallback to `getUser()` if the `kid` of the JWT is not found ([#1080](https://github.com/supabase/auth-js/issues/1080)) ([9721f60](https://github.com/supabase/auth-js/commit/9721f605d3fdd046b5453befa1abfcb755cf7235))
- introduce experimental split user and session storage ([#1023](https://github.com/supabase/auth-js/issues/1023)) ([e7b2f21](https://github.com/supabase/auth-js/commit/e7b2f2169cbbf2cd1e56526c488fc7c169335eac))
- make `getClaims()` non experimental, add global cache ([#1078](https://github.com/supabase/auth-js/issues/1078)) ([ffe13d7](https://github.com/supabase/auth-js/commit/ffe13d7e833f3e53129e152ad3084fb042f9f7c9))
- remove solana dependency by inlining types ([#1079](https://github.com/supabase/auth-js/issues/1079)) ([7665f94](https://github.com/supabase/auth-js/commit/7665f941bbf1f1f420f56b98df01da304f1b2e1d))

### Bug Fixes

- handle null current session with split session storage ([#1071](https://github.com/supabase/auth-js/issues/1071)) ([bc6192a](https://github.com/supabase/auth-js/commit/bc6192afd17e2995ca63acb7fbd4e7ee0b435687))

## [2.70.0](https://github.com/supabase/auth-js/compare/v2.69.1...v2.70.0) (2025-05-16)

### Features

- add `signInWithWeb3` with solana ([#1037](https://github.com/supabase/auth-js/issues/1037)) ([cff5bcb](https://github.com/supabase/auth-js/commit/cff5bcb8399a46b293cfa8688d89882924e7edab))
- validate uuid and sign out scope parameters to functions ([#1063](https://github.com/supabase/auth-js/issues/1063)) ([1bcb76e](https://github.com/supabase/auth-js/commit/1bcb76e479e51cd9bca2d7732d0bf3199e07a693))

### Bug Fixes

- add missing `deleted_at` property to `User` interface ([#1059](https://github.com/supabase/auth-js/issues/1059)) ([96da194](https://github.com/supabase/auth-js/commit/96da194b9ffb88643caa1547084fcee4dbe560f3))
- export `processLock` from toplevel ([#1057](https://github.com/supabase/auth-js/issues/1057)) ([d99695a](https://github.com/supabase/auth-js/commit/d99695af9e632178be94502255c75496cda191ad))

## [2.69.1](https://github.com/supabase/auth-js/compare/v2.69.0...v2.69.1) (2025-03-24)

### Bug Fixes

- `generatePKCEChallenge` should use btoa ([#1044](https://github.com/supabase/auth-js/issues/1044)) ([c06fafb](https://github.com/supabase/auth-js/commit/c06fafbc61fa1dec62ba0183530b6b566a135b75))

## [2.69.0](https://github.com/supabase/auth-js/compare/v2.68.0...v2.69.0) (2025-03-22)

### Features

- introduce getClaims method to verify asymmetric JWTs ([#1030](https://github.com/supabase/auth-js/issues/1030)) ([daa2669](https://github.com/supabase/auth-js/commit/daa266949b336d2e78f2a7b9c9837b70abeab7a6))

### Bug Fixes

- assert type in `decodeJWTPayload` ([#1018](https://github.com/supabase/auth-js/issues/1018)) ([3d80039](https://github.com/supabase/auth-js/commit/3d80039e8b64402b615a924ff82f6562405ff705))
- set jwks_cached_at ([#1039](https://github.com/supabase/auth-js/issues/1039)) ([9bdc023](https://github.com/supabase/auth-js/commit/9bdc0232e5939722606d22bbeaadb131f0dc2734))

## [2.68.0](https://github.com/supabase/auth-js/compare/v2.67.3...v2.68.0) (2025-01-21)

### Features

- consider session expired with margin on getSession() without auto refresh ([#1027](https://github.com/supabase/auth-js/issues/1027)) ([80f88e4](https://github.com/supabase/auth-js/commit/80f88e4bd2809db765a8d103954e827d8473b7db))

### Bug Fixes

- remove `internal-types.ts` ([#1014](https://github.com/supabase/auth-js/issues/1014)) ([28ead89](https://github.com/supabase/auth-js/commit/28ead89af47bcdaccc6cc2f2c7f013bed8cf3d50))
- update docs to add scrypt ([#1012](https://github.com/supabase/auth-js/issues/1012)) ([1225239](https://github.com/supabase/auth-js/commit/1225239e239bde1b25037a88867d4c484caf8301))

## [2.67.3](https://github.com/supabase/auth-js/compare/v2.67.2...v2.67.3) (2024-12-17)

### Bug Fixes

- return redirect errors early ([#1003](https://github.com/supabase/auth-js/issues/1003)) ([9751b80](https://github.com/supabase/auth-js/commit/9751b8029b4235a63dcb525e7ce7cc942c85daf5))

## [2.67.2](https://github.com/supabase/auth-js/compare/v2.67.1...v2.67.2) (2024-12-16)

### Bug Fixes

- `isBrowser()` to include check on `window` ([#982](https://github.com/supabase/auth-js/issues/982)) ([645f224](https://github.com/supabase/auth-js/commit/645f22447e68ba13e43e359d1524e95fe025d771))

## [2.67.1](https://github.com/supabase/auth-js/compare/v2.67.0...v2.67.1) (2024-12-13)

### Bug Fixes

- revert [#992](https://github.com/supabase/auth-js/issues/992) and [#993](https://github.com/supabase/auth-js/issues/993) ([#999](https://github.com/supabase/auth-js/issues/999)) ([12b2848](https://github.com/supabase/auth-js/commit/12b2848237854f3d70b9989920ad50e2c4186fff))

## [2.67.0](https://github.com/supabase/auth-js/compare/v2.66.1...v2.67.0) (2024-12-12)

### Features

- wrap navigator.locks.request with plain promise to help zone.js ([#989](https://github.com/supabase/auth-js/issues/989)) ([2e6e07c](https://github.com/supabase/auth-js/commit/2e6e07c21a561ca13d5e74b69609c2cc93f104f4)), closes [#830](https://github.com/supabase/auth-js/issues/830)

### Bug Fixes

- add email_address_invalid error code ([#994](https://github.com/supabase/auth-js/issues/994)) ([232f133](https://github.com/supabase/auth-js/commit/232f133b1a84b4c667e994f472098aa5cde2088d))
- return error early for redirects ([#992](https://github.com/supabase/auth-js/issues/992)) ([9f32d30](https://github.com/supabase/auth-js/commit/9f32d30e17954c5d4320b374a108617cda5ab357))

## [2.66.1](https://github.com/supabase/auth-js/compare/v2.66.0...v2.66.1) (2024-12-04)

### Bug Fixes

- add loose auto complete to string literals where applicable ([#966](https://github.com/supabase/auth-js/issues/966)) ([fd9248d](https://github.com/supabase/auth-js/commit/fd9248d7aecd0bd00381dff162969d8014a3359a))
- add new error codes ([#979](https://github.com/supabase/auth-js/issues/979)) ([dfb40d2](https://github.com/supabase/auth-js/commit/dfb40d24188f7e8b0d34e51ded15582086250c51))
- don't remove session for identity linking errors ([#987](https://github.com/supabase/auth-js/issues/987)) ([e68ebe6](https://github.com/supabase/auth-js/commit/e68ebe604d15d881b23678d180cccb7115f16f4e))

## [2.66.0](https://github.com/supabase/auth-js/compare/v2.65.1...v2.66.0) (2024-11-01)

### Features

- add process lock for optional use in non-browser environments (React Native) ([#977](https://github.com/supabase/auth-js/issues/977)) ([8af88b6](https://github.com/supabase/auth-js/commit/8af88b6f4e41872b73e84c40f71793dab6c62126))

### Bug Fixes

- typo in warning message ([#975](https://github.com/supabase/auth-js/issues/975)) ([4f21f93](https://github.com/supabase/auth-js/commit/4f21f9324b2c3d55630b8d0a6759a264b0472dd8))
- update soft-deletion docs ([#973](https://github.com/supabase/auth-js/issues/973)) ([cb052a9](https://github.com/supabase/auth-js/commit/cb052a9b0846048feef18080d830cc36a9ed7282))

## [2.65.1](https://github.com/supabase/auth-js/compare/v2.65.0...v2.65.1) (2024-10-14)

### Bug Fixes

- Call `SIGNED_OUT` event where session is removed ([#854](https://github.com/supabase/auth-js/issues/854)) ([436fd9f](https://github.com/supabase/auth-js/commit/436fd9f967ad6d515b8eca179d06032619a1b071))
- improve `mfa.enroll` return types ([#956](https://github.com/supabase/auth-js/issues/956)) ([8a1ec06](https://github.com/supabase/auth-js/commit/8a1ec0602792191bd235d51fd45c0ec2cabdf216))
- move MFA sub types to internal file ([#964](https://github.com/supabase/auth-js/issues/964)) ([4b7455c](https://github.com/supabase/auth-js/commit/4b7455c2631ca4e00f01275c7342eb37756ede23))
- remove phone mfa deletion, match on error codes ([#963](https://github.com/supabase/auth-js/issues/963)) ([ef3911c](https://github.com/supabase/auth-js/commit/ef3911cd1a082a6825ce25fe326081e096bd55f5))

## [2.65.0](https://github.com/supabase/auth-js/compare/v2.64.4...v2.65.0) (2024-08-27)

### Features

- add bindings for Multi-Factor Authentication (Phone) ([#932](https://github.com/supabase/auth-js/issues/932)) ([b957c30](https://github.com/supabase/auth-js/commit/b957c30782065e4cc421a526c62c101d35c443d4))
- add kakao to sign in with ID token ([#845](https://github.com/supabase/auth-js/issues/845)) ([e2337ba](https://github.com/supabase/auth-js/commit/e2337bad535598d9f751505de52a18c59f1505c3))
- remove session, emit `SIGNED_OUT` when JWT `session_id` is invalid ([#905](https://github.com/supabase/auth-js/issues/905)) ([db41710](https://github.com/supabase/auth-js/commit/db41710b1a35ef559158a936d0a95acc0b1fca96))

### Bug Fixes

- Correct typo in GoTrueClient warning message ([#938](https://github.com/supabase/auth-js/issues/938)) ([8222ee1](https://github.com/supabase/auth-js/commit/8222ee198a0ab10570e8b4c31ffb2aeafef86392))
- don't throw error in exchangeCodeForSession ([#946](https://github.com/supabase/auth-js/issues/946)) ([6e161ec](https://github.com/supabase/auth-js/commit/6e161ece3f8cd0d115857e2ed4346533840769f0))
- move docker compose to v2 ([#940](https://github.com/supabase/auth-js/issues/940)) ([38eef89](https://github.com/supabase/auth-js/commit/38eef89ff61b49eb65ee26b7d2201148d1fc3b77))

## [2.64.4](https://github.com/supabase/auth-js/compare/v2.64.3...v2.64.4) (2024-07-12)

### Bug Fixes

- update types ([#930](https://github.com/supabase/auth-js/issues/930)) ([dbc5962](https://github.com/supabase/auth-js/commit/dbc5962d609cc0470b5b03160f4cd8b9e7d03ce3))

## [2.64.3](https://github.com/supabase/auth-js/compare/v2.64.2...v2.64.3) (2024-06-17)

### Bug Fixes

- don't call removeSession prematurely ([#915](https://github.com/supabase/auth-js/issues/915)) ([e0dc518](https://github.com/supabase/auth-js/commit/e0dc51849680fa8f1900de786c4a7e77eab8760e))
- limit proxy session warning to once per client instance ([#900](https://github.com/supabase/auth-js/issues/900)) ([4ecfdda](https://github.com/supabase/auth-js/commit/4ecfdda65188b71322753e57622be8eafe97ed6b))
- patch release workflow ([#922](https://github.com/supabase/auth-js/issues/922)) ([f84fb50](https://github.com/supabase/auth-js/commit/f84fb50a4357af49acac6ca151057d2af74d63c9))
- type errors in verifyOtp ([#918](https://github.com/supabase/auth-js/issues/918)) ([dcd0b9b](https://github.com/supabase/auth-js/commit/dcd0b9b682412a2f1d2deaab26eb8094e50b67fd))

## [2.64.2](https://github.com/supabase/auth-js/compare/v2.64.1...v2.64.2) (2024-05-03)

### Bug Fixes

- signOut should ignore 403s ([#894](https://github.com/supabase/auth-js/issues/894)) ([eeb77ce](https://github.com/supabase/auth-js/commit/eeb77ce2a1ddee94c38f17533c9b748bf2950f67))
- suppress getSession warning whenever \_saveSession is called ([#895](https://github.com/supabase/auth-js/issues/895)) ([59ec9af](https://github.com/supabase/auth-js/commit/59ec9affa01c780fb18f668291fa7167a65c391d))

## [2.64.1](https://github.com/supabase/auth-js/compare/v2.64.0...v2.64.1) (2024-04-25)

### Bug Fixes

- return error if missing session or missing custom auth header ([#891](https://github.com/supabase/auth-js/issues/891)) ([8d16578](https://github.com/supabase/auth-js/commit/8d165787ec46929cba68d18c35161463240f61e3))

## [2.64.0](https://github.com/supabase/auth-js/compare/v2.63.2...v2.64.0) (2024-04-25)

### Features

- remove `cache: no-store` as it breaks cloudflare ([#886](https://github.com/supabase/auth-js/issues/886)) ([10e9d38](https://github.com/supabase/auth-js/commit/10e9d3871c5a9ce50d15c35c7fd7045cad504670))

### Bug Fixes

- Revert "fix: `getUser` returns null if there is no session ([#876](https://github.com/supabase/auth-js/issues/876))" ([#889](https://github.com/supabase/auth-js/issues/889)) ([6755fef](https://github.com/supabase/auth-js/commit/6755fef2aefd1bc84a26182f848c0912492cb106))
- revert check for access token in header ([#885](https://github.com/supabase/auth-js/issues/885)) ([03d8ba7](https://github.com/supabase/auth-js/commit/03d8ba7ca5c485979788d6f121199e4370622491))

## [2.63.2](https://github.com/supabase/auth-js/compare/v2.63.1...v2.63.2) (2024-04-20)

### Bug Fixes

- check for access token in header ([#882](https://github.com/supabase/auth-js/issues/882)) ([ae4a53d](https://github.com/supabase/auth-js/commit/ae4a53de7eb41ebde3b4e1abe823e2ffcb53a71d))

## [2.63.1](https://github.com/supabase/auth-js/compare/v2.63.0...v2.63.1) (2024-04-18)

### Bug Fixes

- `getUser` returns null if there is no session ([#876](https://github.com/supabase/auth-js/issues/876)) ([6adf8ca](https://github.com/supabase/auth-js/commit/6adf8caa4ca803e65f943cc88a2849f5905a044a))
- implement exponential back off on the retries of `_refreshAccessToken` method ([#869](https://github.com/supabase/auth-js/issues/869)) ([f66711d](https://github.com/supabase/auth-js/commit/f66711ddf87ea705a972a860d7ebfb6e0d003c6b))
- update session warning ([#879](https://github.com/supabase/auth-js/issues/879)) ([3661130](https://github.com/supabase/auth-js/commit/36611300fa6d1378a7633c62d2f816d3803f2774))

## [2.63.0](https://github.com/supabase/gotrue-js/compare/v2.62.2...v2.63.0) (2024-03-26)

### Features

- add method for anonymous sign-in ([#858](https://github.com/supabase/gotrue-js/issues/858)) ([e8a1fc9](https://github.com/supabase/gotrue-js/commit/e8a1fc9a40947b949080107138eade09f06f5868))
- add support for error codes ([#855](https://github.com/supabase/gotrue-js/issues/855)) ([99821f4](https://github.com/supabase/gotrue-js/commit/99821f4a1f6fdb3a222cd0f660210016e6cc823e))
- explicit `cache: no-store` in fetch ([#847](https://github.com/supabase/gotrue-js/issues/847)) ([034bee0](https://github.com/supabase/gotrue-js/commit/034bee09c3f0a4613d9a3e7bd3bc5f70682f5a66))
- warn use of `getSession()` when `isServer` on storage ([#846](https://github.com/supabase/gotrue-js/issues/846)) ([9ea94fe](https://github.com/supabase/gotrue-js/commit/9ea94fe11f4a6a4b6305aa4fe75c4661074437a7))

### Bug Fixes

- refactor all pkce code into a single method ([#860](https://github.com/supabase/gotrue-js/issues/860)) ([860bffc](https://github.com/supabase/gotrue-js/commit/860bffc8f75292e71630fb7241e11a754200dab8))
- remove data type ([#848](https://github.com/supabase/gotrue-js/issues/848)) ([15c7c82](https://github.com/supabase/gotrue-js/commit/15c7c8258b2d42d3378be4f7738c728a07523579))
