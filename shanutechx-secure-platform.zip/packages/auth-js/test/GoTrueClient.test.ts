import { AuthError, AuthPKCECodeVerifierMissingError } from '../src/lib/errors'
import { JWK, Session } from '../src'
import GoTrueClient from '../src/GoTrueClient'
import { base64UrlToUint8Array } from '../src/lib/base64url'
import {
  AUTO_REFRESH_TICK_DURATION_MS,
  REFRESH_FAILURE_COOLDOWN_MS,
  STORAGE_KEY,
} from '../src/lib/constants'
import { getItemAsync, setItemAsync } from '../src/lib/helpers'
import { memoryLocalStorageAdapter } from '../src/lib/local-storage'
import {
  deserializeCredentialCreationOptions,
  deserializeCredentialRequestOptions,
  serializeCredentialCreationResponse,
  serializeCredentialRequestResponse,
} from '../src/lib/webauthn'
import type { PublicKeyCredentialFuture, PublicKeyCredentialJSON } from '../src/lib/webauthn.dom'
import {
  authClient as auth,
  authSubscriptionClient,
  clientApiAutoConfirmEnabledClient as signUpEnabledClient,
  authAdminApiAutoConfirmEnabledClient,
  authClient,
  pkceClient,
  authClientWithSession as authWithSession,
  autoRefreshClient,
  getClientWithSpecificStorage,
  GOTRUE_URL_SIGNUP_ENABLED_AUTO_CONFIRM_ON,
} from './lib/clients'
import { mockUserCredentials } from './lib/utils'
import {
  webauthnCreationCredentialResponse,
  webauthnCreationMockCredential,
} from './webauthn.fixtures'

const TEST_USER_DATA = { info: 'some info' }

const expiredAccessToken =
  'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJhdWQiOiJhdXRoZW50aWNhdGVkIiwiZXhwIjoxNzQ4MTA3MDc0LCJpYXQiOjE3NDgxMDM0NzQsImlzcyI6Imh0dHBzOi8vZXhhbXBsZS5jb20iLCJzdWIiOiIxMjM0NTY3ODkwIiwidXNlcl9tZXRhZGF0YSI6e30sInJvbGUiOiJhdXRoZW50aWNhdGVkIn0.SflKxwRJSMeKKF2QT4fwpMeJf36POk6yJV_adQssw5c'

describe('GoTrueClient', () => {
  // @ts-expect-error 'Allow access to private _refreshAccessToken'
  const refreshAccessTokenSpy = jest.spyOn(authWithSession, '_refreshAccessToken')

  afterEach(async () => {
    await auth.signOut()
    await authWithSession.signOut()
    refreshAccessTokenSpy.mockClear()
  })

  test('should handle debug function in settings', async () => {
    const debugSpy = jest.fn()
    const client = new GoTrueClient({
      url: 'http://localhost:9999',
      debug: debugSpy,
    })

    await client.initialize()
    expect(debugSpy).toHaveBeenCalled()
  })

  test('should handle custom lock implementation', async () => {
    const customLock = jest
      .fn()
      .mockImplementation(async (_name: string, _timeout: number, fn: () => Promise<unknown>) =>
        fn()
      )
    const client = new GoTrueClient({
      url: 'http://localhost:9999',
      lock: customLock,
    })

    await client.initialize()
    expect(customLock).toHaveBeenCalled()
  })

  test('should handle userStorage configuration', async () => {
    const userStorage = memoryLocalStorageAdapter()
    const client = new GoTrueClient({
      url: 'http://localhost:9999',
      userStorage,
    })

    await client.initialize()
    expect(client['userStorage']).toBe(userStorage)
  })

  describe('Sessions', () => {
    test('refreshSession() should return a new session using a passed-in refresh token', async () => {
      const { email, password } = mockUserCredentials()

      const { error, data } = await authWithSession.signUp({
        email,
        password,
      })
      expect(error).toBeNull()
      expect(data.session).not.toBeNull()

      /** wait 1 second before calling refreshSession()
       * resolves issue of tokens being equal
       */
      await new Promise((r) => setTimeout(r, 1000))

      const {
        data: { session },
        error: refreshSessionError,
      } = await authWithSession.refreshSession({
        // @ts-expect-error 'data.session should not be null because of the assertion above'
        refresh_token: data.session.refresh_token,
      })
      expect(refreshSessionError).toBeNull()
      expect(session).not.toBeNull()
      expect(session!.user).not.toBeNull()
      expect(session!.expires_in).not.toBeNull()
      expect(session!.expires_at).not.toBeNull()
      expect(session!.access_token).not.toBeNull()
      expect(session!.refresh_token).not.toBeNull()
      expect(session!.token_type).toStrictEqual('bearer')
      expect(refreshAccessTokenSpy).toHaveBeenCalledTimes(1)
      // @ts-expect-error 'data.session and session should not be null because of the assertion above'
      expect(data.session.refresh_token).not.toEqual(session.refresh_token)
    })

    test('refreshSession() should return a new session without a passed-in refresh token', async () => {
      const { email, password } = mockUserCredentials()

      const { error, data } = await authWithSession.signUp({
        email,
        password,
      })
      expect(error).toBeNull()
      expect(data.session).not.toBeNull()

      /** wait 1 second before calling refreshSession()
       * resolves issue of tokens being equal
       */
      await new Promise((r) => setTimeout(r, 1000))

      const {
        data: { session },
        error: refreshSessionError,
      } = await authWithSession.refreshSession()
      expect(refreshSessionError).toBeNull()
      expect(session).not.toBeNull()
      expect(session!.user).not.toBeNull()
      expect(session!.expires_in).not.toBeNull()
      expect(session!.expires_at).not.toBeNull()
      expect(session!.access_token).not.toBeNull()
      expect(session!.refresh_token).not.toBeNull()
      expect(session!.token_type).toStrictEqual('bearer')
      expect(refreshAccessTokenSpy).toHaveBeenCalledTimes(1)
      // @ts-expect-error 'data.session and session should not be null because of the assertion above'
      expect(data.session.refresh_token).not.toEqual(session.refresh_token)
    })

    test('setSession should return no error', async () => {
      const { email, password } = mockUserCredentials()

      const { error, data } = await authWithSession.signUp({
        email,
        password,
      })
      expect(error).toBeNull()
      expect(data.session).not.toBeNull()

      const {
        data: { session },
        error: setSessionError,
      } = await authWithSession.setSession({
        // @ts-expect-error 'data.session should not be null because of the assertion above'
        access_token: data.session.access_token,
        // @ts-expect-error 'data.session should not be null because of the assertion above'
        refresh_token: data.session.refresh_token,
      })
      expect(setSessionError).toBeNull()
      expect(session).not.toBeNull()
      expect(session!.user).not.toBeNull()
      expect(session!.expires_in).not.toBeNull()
      expect(session!.expires_at).not.toBeNull()
      expect(session!.access_token).not.toBeNull()
      expect(session!.refresh_token).not.toBeNull()
      expect(session!.token_type).toStrictEqual('bearer')

      /**
       * getSession has been added to verify setSession is also saving
       * the session, not just returning it.
       */
      const { data: getSessionData, error: getSessionError } = await authWithSession.getSession()
      expect(getSessionError).toBeNull()
      expect(getSessionData).not.toBeNull()

      const {
        data: { user },
        error: updateError,
      } = await authWithSession.updateUser({ data: { hello: 'world' } })

      expect(updateError).toBeNull()
      expect(user).not.toBeNull()
      expect(user?.user_metadata).toMatchObject({ hello: 'world' })
    })

    test('setSession should fail with invalid access token', async () => {
      const { email, password } = mockUserCredentials()

      const { error, data } = await authWithSession.signUp({
        email,
        password,
      })
      expect(error).toBeNull()
      expect(data.session).not.toBeNull()

      const {
        data: { session },
        error: setSessionError,
      } = await authWithSession.setSession({
        access_token: 'invalid-access-token',
        // @ts-expect-error 'data.session should not be null because of the assertion above'
        refresh_token: data.session.refresh_token,
      })
      expect(setSessionError).not.toBeNull()
      expect(setSessionError?.message).toContain('Invalid JWT structure')
      expect(session).toBeNull()
    })

    test('setSession should fail with invalid refresh token', async () => {
      const { email, password } = mockUserCredentials()

      const { error, data } = await authWithSession.signUp({
        email,
        password,
      })
      expect(error).toBeNull()
      expect(data.session).not.toBeNull()

      const {
        data: { session },
        error: setSessionError,
      } = await authWithSession.setSession({
        access_token: expiredAccessToken,
        refresh_token: 'invalid-refresh-token',
      })

      expect(setSessionError).not.toBeNull()
      // Error message varies between GoTrue versions
      expect(
        setSessionError?.message?.includes('Invalid Refresh Token') ||
          setSessionError?.message?.includes('Refresh token is not valid')
      ).toBe(true)
      expect(session).toBeNull()
    })

    test('setSession should fail without refresh_token', async () => {
      const {
        data: { session },
        error: setSessionError,
      } = await authWithSession.setSession({
        access_token: 'valid-access-token',
      } as any)
      expect(setSessionError).not.toBeNull()
      expect(setSessionError?.message).toContain('Auth session missing!')
      expect(session).toBeNull()
    })

    test('setSession should fail without access_token', async () => {
      const {
        data: { session },
        error: setSessionError,
      } = await authWithSession.setSession({
        refresh_token: 'valid-refresh-token',
      } as any)
      expect(setSessionError).not.toBeNull()
      expect(setSessionError?.message).toContain('Auth session missing!')
      expect(session).toBeNull()
    })

    test('getSession() should return the currentUser session', async () => {
      const { email, password } = mockUserCredentials()

      const { error, data } = await authWithSession.signUp({
        email,
        password,
      })

      expect(error).toBeNull()
      expect(data.session).not.toBeNull()

      const { data: userSession, error: userError } = await authWithSession.getSession()

      expect(userError).toBeNull()
      expect(userSession.session).not.toBeNull()
      expect(userSession.session).toHaveProperty('access_token')
      expect(userSession.session).toHaveProperty('user')
    })

    test('getSession() should refresh the session and return a new access token', async () => {
      const { email, password } = mockUserCredentials()

      const { error, data } = await authWithSession.signUp({
        email,
        password,
      })

      expect(error).toBeNull()
      expect(data.session).not.toBeNull()

      const expired = new Date()
      expired.setMinutes(expired.getMinutes() - 1)
      const expiredSeconds = Math.floor(expired.getTime() / 1000)

      // @ts-expect-error 'Allow access to protected storage'
      const storage = authWithSession.storage

      // @ts-expect-error 'Allow access to protected storageKey'
      const storageKey = authWithSession.storageKey

      await storage.setItem(
        storageKey,
        JSON.stringify({
          ...JSON.parse((await storage.getItem(storageKey)) || 'null'),
          expires_at: expiredSeconds,
        })
      )

      // wait 1 seconds before calling getSession()
      await new Promise((r) => setTimeout(r, 1000))
      const { data: userSession, error: userError } = await authWithSession.getSession()

      expect(userError).toBeNull()
      expect(userSession.session).not.toBeNull()
      expect(userSession.session).toHaveProperty('access_token')
      expect(refreshAccessTokenSpy).toHaveBeenCalledTimes(1)
      expect(data.session?.access_token).not.toEqual(userSession.session?.access_token)
    })

    test('getSession() returns null when no session is stored', async () => {
      const { data, error } = await auth.getSession()
      expect(data?.session).toBeNull()
      expect(error).toBeNull()
    })

    test('getSession() returns null when no session is stored', async () => {
      const { data, error } = await auth.getSession()
      expect(data?.session).toBeNull()
      expect(error).toBeNull()
    })

    test('refresh should only happen once', async () => {
      const { email, password } = mockUserCredentials()

      const { error, data } = await authWithSession.signUp({
        email,
        password,
      })

      expect(error).toBeNull()
      expect(data.session).not.toBeNull()

      const [{ data: session1, error: error1 }, { data: session2, error: error2 }] =
        await Promise.all([
          // @ts-expect-error 'Allow access to private _callRefreshToken()'
          authWithSession._callRefreshToken(data.session?.refresh_token),
          // @ts-expect-error 'Allow access to private _callRefreshToken()'
          authWithSession._callRefreshToken(data.session?.refresh_token),
        ])

      expect(error1).toBeNull()
      expect(error2).toBeNull()
      expect(session1).toHaveProperty('access_token')
      expect(session2).toHaveProperty('access_token')

      // if both have the same access token, we can assume that they are
      // the result of the same refresh
      expect(session1?.access_token).toEqual(session2?.access_token)

      expect(refreshAccessTokenSpy).toHaveBeenCalledTimes(1)
    })

    test('_callRefreshToken() should resolve all pending refresh requests and reset deferred upon AuthError', async () => {
      const { email, password } = mockUserCredentials()
      refreshAccessTokenSpy.mockImplementationOnce(() =>
        // @ts-expect-error 'Allow access to private _refreshAccessToken()'
        Promise.resolve({
          data: { session: null, user: null },
          error: new AuthError('Something did not work as expected'),
        })
      )

      const { error, data } = await authWithSession.signUp({
        email,
        password,
      })

      expect(error).toBeNull()
      expect(data.session).not.toBeNull()

      const [{ data: session1, error: error1 }, { data: session2, error: error2 }] =
        await Promise.all([
          // @ts-expect-error 'Allow access to private _callRefreshToken()'
          authWithSession._callRefreshToken(data.session?.refresh_token),
          // @ts-expect-error 'Allow access to private _callRefreshToken()'
          authWithSession._callRefreshToken(data.session?.refresh_token),
        ])

      expect(error1).toHaveProperty('message')
      expect(error2).toHaveProperty('message')
      expect(session1).toBeNull()
      expect(session2).toBeNull()

      expect(refreshAccessTokenSpy).toHaveBeenCalledTimes(1)

      // The failure cooldown would normally short-circuit the next serial
      // caller; clear it so this test continues to verify the deferred
      // itself has been reset (the cooldown is exercised in its own block
      // below).
      // @ts-expect-error 'Allow access to private lastRefreshFailure'
      authWithSession.lastRefreshFailure = null

      // verify the deferred has been reset and successive calls can be made
      // @ts-expect-error 'Allow access to private _callRefreshToken()'
      const { data: session3, error: error3 } = await authWithSession._callRefreshToken(
        data.session!.refresh_token
      )

      expect(error3).toBeNull()
      expect(session3).toHaveProperty('access_token')
    })

    test('_callRefreshToken() should reject all pending refresh requests and reset deferred upon any non AuthError', async () => {
      const mockError = new Error('Something did not work as expected')

      const { email, password } = mockUserCredentials()

      // @ts-expect-error 'Allow access to private _refreshAccessToken()'
      refreshAccessTokenSpy.mockImplementationOnce(() => Promise.reject(mockError))

      const { error, data } = await authWithSession.signUp({
        email,
        password,
      })

      expect(error).toBeNull()
      expect(data.session).not.toBeNull()

      const [error1, error2] = await Promise.allSettled([
        // @ts-expect-error 'Allow access to private _callRefreshToken()'
        authWithSession._callRefreshToken(data.session?.refresh_token),
        // @ts-expect-error 'Allow access to private _callRefreshToken()'
        authWithSession._callRefreshToken(data.session?.refresh_token),
      ])

      expect(error1.status).toEqual('rejected')
      expect(error2.status).toEqual('rejected')

      // status === 'rejected' above makes sure it is a PromiseRejectedResult
      expect((error1 as PromiseRejectedResult).reason).toEqual(mockError)
      expect((error1 as PromiseRejectedResult).reason).toEqual(mockError)

      expect(refreshAccessTokenSpy).toHaveBeenCalledTimes(1)

      // vreify the deferred has been reset and successive calls can be made
      // @ts-expect-error 'Allow access to private _callRefreshToken()'
      const { data: session3, error: error3 } = await authWithSession._callRefreshToken(
        data.session!.refresh_token
      )

      expect(error3).toBeNull()
      expect(session3).toHaveProperty('access_token')
    })

    test('_getSessionFromURL() can only be called from a browser', async () => {
      const {
        error,
        data: { session },
        // @ts-expect-error 'Allow access to private _getSessionFromURL()'
      } = await authWithSession._getSessionFromURL()

      expect(error?.message).toEqual('No browser detected.')
      expect(session).toBeNull()
    })

    test('exchangeCodeForSession() should fail with invalid authCode', async () => {
      // Mock fetch to return a 400 error for invalid auth code
      const mockFetch = jest.fn().mockResolvedValue({
        ok: false,
        status: 400,
        headers: new Headers(),
        json: () =>
          Promise.resolve({
            error: 'invalid_grant',
            error_description: 'Invalid auth code',
          }),
      })

      const storage = memoryLocalStorageAdapter()
      const client = new GoTrueClient({
        url: GOTRUE_URL_SIGNUP_ENABLED_AUTO_CONFIRM_ON,
        autoRefreshToken: false,
        persistSession: true,
        storage,
        flowType: 'pkce',
        fetch: mockFetch,
      })

      // Set up a code verifier so we can test the invalid auth code error
      // @ts-expect-error 'Allow access to protected storageKey'
      const storageKey = client.storageKey
      await storage.setItem(`${storageKey}-code-verifier`, 'mock-verifier')

      const { error } = await client.exchangeCodeForSession('mock_code')

      expect(error).not.toBeNull()
      expect(error?.status).toEqual(400)
    })

    test('exchangeCodeForSession() should throw helpful error when code verifier is missing', async () => {
      const storage = memoryLocalStorageAdapter()
      // Don't set a code verifier - this simulates the common issue where
      // the auth flow was initiated in a different browser/device

      const client = new GoTrueClient({
        url: GOTRUE_URL_SIGNUP_ENABLED_AUTO_CONFIRM_ON,
        autoRefreshToken: false,
        persistSession: true,
        storage,
        flowType: 'pkce',
      })

      const { error } = await client.exchangeCodeForSession('some-auth-code')

      expect(error).toBeInstanceOf(AuthPKCECodeVerifierMissingError)
      expect(error?.message).toContain('PKCE code verifier not found in storage')
      expect(error?.message).toContain('@shanutechx/ssr')
      expect(error?.code).toEqual('pkce_code_verifier_not_found')
    })
  })

  describe('Email Auth', () => {
    test('signUp() with email', async () => {
      const { email, password } = mockUserCredentials()

      const { error, data } = await auth.signUp({
        email,
        password,
      })

      expect(error).toBeNull()
      expect(data.session).not.toBeNull()
      expect(data.user).not.toBeNull()

      expect(data.user?.email).toEqual(email)
    })

    test('signUp() with email and PKCE flowType', async () => {
      const { email, password } = mockUserCredentials()

      const { error, data } = await pkceClient.signUp({ email, password })

      expect(error).toBeNull()
      expect(data.session).not.toBeNull()
      expect(data.user).not.toBeNull()
      expect(data.user?.email).toEqual(email)
    })

    test('signUp() with email and options', async () => {
      const { email, password } = mockUserCredentials()

      const { error, data } = await auth.signUp({
        email,
        password,
        options: {
          emailRedirectTo: email,
          data: { ...TEST_USER_DATA },
        },
      })

      expect(error).toBeNull()
      expect(data.session).not.toBeNull()
      expect(data.user).not.toBeNull()

      expect(data.user?.email).toEqual(email)
      expect(data?.user?.user_metadata).toMatchObject(TEST_USER_DATA)
    })

    test('signUp() returns the bare user payload when signup requires confirmation', async () => {
      const user = {
        id: 'user-id',
        aud: 'authenticated',
        role: 'authenticated',
        email: 'user@example.com',
        created_at: '2026-05-21T12:00:00.000Z',
      }
      const mockFetch = jest.fn().mockResolvedValue({
        ok: true,
        status: 200,
        headers: new Headers(),
        json: () => Promise.resolve(user),
      })
      const client = new GoTrueClient({
        url: GOTRUE_URL_SIGNUP_ENABLED_AUTO_CONFIRM_ON,
        autoRefreshToken: false,
        persistSession: false,
        storage: memoryLocalStorageAdapter(),
        fetch: mockFetch as unknown as typeof fetch,
      })

      const { data, error } = await client.signUp({
        email: user.email,
        password: 'password123',
      })

      expect(error).toBeNull()
      expect(data.session).toBeNull()
      expect(data.user).toEqual(user)
    })

    test('fail to signUp() with invalid password', async () => {
      const { error, data } = await auth.signUp({ email: 'asd@a.aa', password: '123' })

      expect(data?.session).toBeNull()
      expect(error).not.toBeNull()
      expect(error?.message).toContain('Password should be at least 6 characters')
    })

    test('fail to signUp() with invalid email', async () => {
      const { error, data } = await auth.signUp({ email: 'a', password: '123456' })

      expect(data?.session).toBeNull()
      expect(error).not.toBeNull()
      expect(error?.message).toContain('Unable to validate email address: invalid format')
    })

    test.each([
      {
        name: 'resend with email with options',
        params: {
          email: mockUserCredentials().email,
          type: 'signup' as const,
          options: { emailRedirectTo: mockUserCredentials().email },
        },
      },
      {
        name: 'resend with email with empty options',
        params: {
          email: mockUserCredentials().email,
          type: 'signup' as const,
          options: {},
        },
      },
    ])('$name', async ({ params }) => {
      const { error } = await auth.resend(params)
      expect(error).toBeNull()
    })

    test('resend with email and PKCE flowType includes code_challenge in request', async () => {
      const mockFetch = jest.fn().mockResolvedValue({
        ok: true,
        status: 200,
        headers: new Headers(),
        json: () => Promise.resolve({}),
      })

      const storage = memoryLocalStorageAdapter()
      const client = new GoTrueClient({
        url: GOTRUE_URL_SIGNUP_ENABLED_AUTO_CONFIRM_ON,
        autoRefreshToken: false,
        persistSession: true,
        storage,
        flowType: 'pkce',
        fetch: mockFetch,
      })

      const { email } = mockUserCredentials()
      const { error } = await client.resend({
        email,
        type: 'signup',
        options: { emailRedirectTo: 'http://localhost:9999/welcome' },
      })
      expect(error).toBeNull()

      // Verify code_challenge was included in the request body
      expect(mockFetch).toHaveBeenCalledTimes(1)
      const [, fetchOptions] = mockFetch.mock.calls[0]
      const body = JSON.parse(fetchOptions.body)
      expect(body.code_challenge).toBeDefined()
      expect(body.code_challenge).not.toBeNull()
      expect(body.code_challenge_method).toBe('s256')

      // Verify code verifier was stored for later exchange
      // @ts-expect-error 'Allow access to protected storageKey'
      const storageKey = client.storageKey
      const codeVerifier = await storage.getItem(`${storageKey}-code-verifier`)
      expect(codeVerifier).not.toBeNull()
    })

    test('resend with email_change type and PKCE flowType includes code_challenge', async () => {
      const mockFetch = jest.fn().mockResolvedValue({
        ok: true,
        status: 200,
        headers: new Headers(),
        json: () => Promise.resolve({}),
      })

      const storage = memoryLocalStorageAdapter()
      const client = new GoTrueClient({
        url: GOTRUE_URL_SIGNUP_ENABLED_AUTO_CONFIRM_ON,
        autoRefreshToken: false,
        persistSession: true,
        storage,
        flowType: 'pkce',
        fetch: mockFetch,
      })

      const { error } = await client.resend({
        email: 'newemail@example.com',
        type: 'email_change',
      })
      expect(error).toBeNull()

      // Verify code_challenge was included in the request body
      expect(mockFetch).toHaveBeenCalledTimes(1)
      const [, fetchOptions] = mockFetch.mock.calls[0]
      const body = JSON.parse(fetchOptions.body)
      expect(body.code_challenge).toBeDefined()
      expect(body.code_challenge).not.toBeNull()
      expect(body.code_challenge_method).toBe('s256')
      expect(body.type).toBe('email_change')

      // @ts-expect-error 'Allow access to protected storageKey'
      const storageKey = client.storageKey
      const codeVerifier = await storage.getItem(`${storageKey}-code-verifier`)
      expect(codeVerifier).not.toBeNull()
    })

    test('resend with PKCE cleans up code verifier on HTTP error', async () => {
      const mockFetch = jest.fn().mockResolvedValue({
        ok: false,
        status: 400,
        headers: new Headers(),
        json: () =>
          Promise.resolve({
            error: 'bad_request',
            error_description: 'Invalid email',
          }),
      })

      const storage = memoryLocalStorageAdapter()
      const client = new GoTrueClient({
        url: GOTRUE_URL_SIGNUP_ENABLED_AUTO_CONFIRM_ON,
        autoRefreshToken: false,
        persistSession: true,
        storage,
        flowType: 'pkce',
        fetch: mockFetch,
      })

      const { error } = await client.resend({
        email: 'bad@example.com',
        type: 'signup',
      })
      expect(error).not.toBeNull()

      // Verify code verifier was cleaned up after HTTP error
      // @ts-expect-error 'Allow access to protected storageKey'
      const storageKey = client.storageKey
      const codeVerifier = await storage.getItem(`${storageKey}-code-verifier`)
      expect(codeVerifier).toBeNull()
    })

    test('resend without PKCE does not include code_challenge in request', async () => {
      const mockFetch = jest.fn().mockResolvedValue({
        ok: true,
        status: 200,
        headers: new Headers(),
        json: () => Promise.resolve({}),
      })

      const storage = memoryLocalStorageAdapter()
      const client = new GoTrueClient({
        url: GOTRUE_URL_SIGNUP_ENABLED_AUTO_CONFIRM_ON,
        autoRefreshToken: false,
        persistSession: true,
        storage,
        fetch: mockFetch,
      })

      const { error } = await client.resend({
        email: 'test@example.com',
        type: 'signup',
      })
      expect(error).toBeNull()

      // Verify code_challenge fields are null in implicit flow
      expect(mockFetch).toHaveBeenCalledTimes(1)
      const [, fetchOptions] = mockFetch.mock.calls[0]
      const body = JSON.parse(fetchOptions.body)
      expect(body.code_challenge).toBeNull()
      expect(body.code_challenge_method).toBeNull()
    })

    // Phone resend tests moved to docker-tests/phone-otp.test.ts

    test('resend() fails without email or phone', async () => {
      const { error } = await auth.resend({} as any)

      expect(error).not.toBeNull()
      expect(error?.message).toContain('You must provide either an email or phone number')
    })

    test('signUp() should fail when both email and phone are missing', async () => {
      const { data, error } = await auth.signUp({
        password: 'password123',
      } as any)

      expect(error).not.toBeNull()
      expect(error?.message).toContain(
        'You must provide either an email or phone number and a password'
      )
      expect(data.session).toBeNull()
      expect(data.user).toBeNull()
    })

    test('should handle signUp with invalid credentials', async () => {
      const { data, error } = await auth.signUp({
        email: 'invalid-email',
        password: '123', // too short
      })

      expect(error).toBeDefined()
      expect(data.user).toBeNull()
      expect(data.session).toBeNull()
    })

    test('should handle signInWithPassword with invalid credentials', async () => {
      const { data, error } = await auth.signInWithPassword({
        email: 'nonexistent@example.com',
        password: 'wrongpassword',
      })

      expect(error).toBeDefined()
      expect(data.user).toBeNull()
      expect(data.session).toBeNull()
    })

    test('should handle signInWithOAuth with invalid provider', async () => {
      const { data, error } = await auth.signInWithOAuth({
        provider: 'invalid-provider' as any,
      })

      expect(error).toBeNull()
      expect(data.url).toBeDefined()
    })

    test('should handle signInWithOtp with invalid email', async () => {
      const { data, error } = await auth.signInWithOtp({
        email: 'invalid-email',
      })

      expect(error).toBeDefined()
      expect(data.user).toBeNull()
    })

    test('should handle signInWithOtp with invalid phone', async () => {
      const { data, error } = await auth.signInWithOtp({
        phone: 'invalid-phone',
      })

      expect(error).toBeDefined()
      expect(data.user).toBeNull()
    })

    test('should handle verifyOtp with invalid code', async () => {
      const { data, error } = await auth.verifyOtp({
        email: 'test@example.com',
        token: 'invalid-token',
        type: 'email',
      })

      expect(error).toBeDefined()
      expect(data.user).toBeNull()
      expect(data.session).toBeNull()
    })

    test('verifyOtp() returns null user and session for email_change single-confirmation response', async () => {
      // When secure email change is enabled, gotrue's POST /verify returns
      // `{ msg, code }` (200 OK) after the first of two confirmations succeeds.
      // The SDK must not surface that object as `data.user`.
      const mockFetch = jest.fn().mockResolvedValue({
        ok: true,
        status: 200,
        headers: new Headers(),
        json: () =>
          Promise.resolve({
            code: '200',
            msg: 'Confirmation link accepted. Please proceed to confirm link sent to the other email',
          }),
      })

      const client = new GoTrueClient({
        url: GOTRUE_URL_SIGNUP_ENABLED_AUTO_CONFIRM_ON,
        autoRefreshToken: false,
        persistSession: false,
        storage: memoryLocalStorageAdapter(),
        fetch: mockFetch as unknown as typeof fetch,
      })

      const { data, error } = await client.verifyOtp({
        token_hash: 'token-hash',
        type: 'email_change',
      })

      expect(error).toBeNull()
      expect(data.user).toBeNull()
      expect(data.session).toBeNull()
    })
  })

  describe('signInWithOtp', () => {
    test('signInWithOtp() for email', async () => {
      const { email } = mockUserCredentials()
      const userMetadata = { hello: 'world' }
      const { data, error } = await auth.signInWithOtp({
        email,
        options: {
          data: userMetadata,
        },
      })
      expect(error).toBeNull()
      expect(data.user).toBeNull()
      expect(data.session).toBeNull()
    })

    test.each([
      {
        name: 'signInWithOtp for email with empty options',
        testFn: async () => {
          const { email } = mockUserCredentials()
          const { data, error } = await auth.signInWithOtp({
            email,
            options: {},
          })
          expect(error).toBeNull()
          expect(data.user).toBeNull()
          expect(data.session).toBeNull()
        },
      },
      {
        name: 'verifyOTP fails with empty options',
        testFn: async () => {
          const { phone } = mockUserCredentials()

          const { error } = await auth.verifyOtp({
            phone,
            type: 'phone_change',
            token: '123456',
            options: {},
          })

          expect(error).not.toBeNull()
          expect(error?.message).toContain('Token has expired or is invalid')
        },
      },
    ])('$name', async ({ testFn }) => {
      await testFn()
    })

    test('signInWithOtp() pkce flow fails with invalid sms provider', async () => {
      const { phone } = mockUserCredentials()

      const { data, error } = await pkceClient.signInWithOtp({
        phone,
      })
      expect(error).not.toBeNull()
      expect(data.session).toBeNull()
      expect(data.user).toBeNull()
    })

    test('signInWithOtp() should fail when both email and phone are missing', async () => {
      const { data, error } = await auth.signInWithOtp({
        options: {
          data: { hello: 'world' },
        },
      } as any)

      expect(error).not.toBeNull()
      expect(error?.message).toContain('You must provide either an email or phone number')
      expect(data.session).toBeNull()
      expect(data.user).toBeNull()
    })

    test('signInWithOtp() with PKCE flow should return error', async () => {
      const { email } = mockUserCredentials()
      const { data, error } = await pkceClient.signInWithOtp({
        email,
        options: {
          shouldCreateUser: false,
          captchaToken: 'some_token',
          emailRedirectTo: email,
        },
      })

      expect(error).not.toBeNull()
      expect(data.session).toBeNull()
      expect(data.user).toBeNull()
    })
  })

  // Phone OTP Auth tests moved to docker-tests/phone-otp.test.ts

  test('signUp() the same user twice should not share email already registered message', async () => {
    const { email, password } = mockUserCredentials()

    await auth.signUp({
      email,
      password,
    })

    // sign up again
    const { error, data } = await auth.signUp({
      email,
      password,
    })

    expect(data.session).toBeNull()
    expect(data.user).toBeNull()

    expect(error?.message).toMatch(/^User already registered/)
  })

  // signInWithPassword() for phone test moved to docker-tests/phone-otp.test.ts

  test('signInWithPassword() for email', async () => {
    const { email, password } = mockUserCredentials()

    await auth.signUp({
      email,
      password,
    })

    const { error, data } = await auth.signInWithPassword({
      email,
      password,
    })

    const expectedUser = {
      id: expect.any(String),
      email: expect.any(String),
      phone: expect.any(String),
      aud: expect.any(String),
      email_confirmed_at: expect.any(String),
      last_sign_in_at: expect.any(String),
      created_at: expect.any(String),
      updated_at: expect.any(String),
      app_metadata: {
        provider: 'email',
      },
    }
    expect(error).toBeNull()
    expect(data.session).toMatchObject({
      access_token: expect.any(String),
      refresh_token: expect.any(String),
      expires_in: expect.any(Number),
      expires_at: expect.any(Number),
      user: expectedUser,
    })
    expect(data.user).toMatchObject(expectedUser)
    expect(data.user?.email).toBe(email)
  })

  test('signIn() with refreshToken', async () => {
    const { email, password } = mockUserCredentials()

    const { error: initialError, data } = await authWithSession.signUp({
      email,
      password,
    })

    expect(initialError).toBeNull()
    const initialSession = data.session
    expect(initialSession).not.toBeNull()

    const { data: userSession, error } = await authWithSession.getSession()

    expect(error).toBeNull()
    expect(userSession.session).toMatchObject({
      access_token: expect.any(String),
      refresh_token: expect.any(String),
      expires_in: expect.any(Number),
      expires_at: expect.any(Number),
      user: {
        id: expect.any(String),
        email: expect.any(String),
        phone: expect.any(String),
        aud: expect.any(String),
        email_confirmed_at: expect.any(String),
        last_sign_in_at: expect.any(String),
        created_at: expect.any(String),
        updated_at: expect.any(String),
        app_metadata: {
          provider: 'email',
        },
      },
    })
    expect(userSession.session?.user).toMatchObject({
      id: expect.any(String),
      email: expect.any(String),
      phone: expect.any(String),
      aud: expect.any(String),
      email_confirmed_at: expect.any(String),
      last_sign_in_at: expect.any(String),
      created_at: expect.any(String),
      updated_at: expect.any(String),
      app_metadata: {
        provider: 'email',
      },
    })

    expect(userSession.session?.user).not.toBeNull()
    expect(userSession.session?.user?.email).toBe(email)
  })
})

describe('Signout behaviour', () => {
  test('signOut', async () => {
    const { email, password } = mockUserCredentials()

    await authWithSession.signUp({
      email,
      password,
    })

    await authWithSession.signInWithPassword({
      email,
      password,
    })

    const { error } = await authWithSession.signOut()

    expect(error).toBe(null)
    const {
      data: { user },
    } = await authWithSession.getUser()
    expect(user).toBe(null)
  })

  test('signOut should remove session if user is not found or jwt is invalid', async () => {
    const { email, password } = mockUserCredentials()

    await authWithSession.signUp({
      email,
      password,
    })

    const {
      data: { user },
      error: signInError,
    } = await authWithSession.signInWithPassword({
      email,
      password,
    })
    expect(signInError).toBe(null)
    expect(user).not.toBe(null)

    const {
      data: { session },
      error: sessionError,
    } = await authWithSession.getSession()
    expect(session).not.toBe(null)
    expect(sessionError).toBe(null)

    const id = user ? user.id : '' // user should not be null
    await authAdminApiAutoConfirmEnabledClient.deleteUser(id)

    const { error } = await authWithSession.signOut()
    expect(error).toBe(null)
  })
})

describe('User management', () => {
  test('Get user', async () => {
    const { email, password } = mockUserCredentials()

    const { data } = await authWithSession.signUp({
      email,
      password,
    })

    expect(data.user).toMatchObject({
      id: expect.any(String),
      email: expect.any(String),
      phone: expect.any(String),
      aud: expect.any(String),
      email_confirmed_at: expect.any(String),
      last_sign_in_at: expect.any(String),
      created_at: expect.any(String),
      updated_at: expect.any(String),
      app_metadata: {
        provider: 'email',
      },
    })

    expect(data.user?.email).toBe(email)
  })

  test('Update user', async () => {
    const { email, password } = mockUserCredentials()

    await authWithSession.signUp({
      email,
      password,
    })

    const userMetadata = { hello: 'world' }

    const {
      error,
      data: { user },
    } = await authWithSession.updateUser({ data: userMetadata })

    expect(error).toBeNull()
    expect(user).toMatchObject({
      id: expect.any(String),
      aud: expect.any(String),
      email: expect.any(String),
      phone: expect.any(String),
      updated_at: expect.any(String),
      last_sign_in_at: expect.any(String),
      email_confirmed_at: expect.any(String),
      created_at: expect.any(String),
      user_metadata: {
        hello: 'world',
      },
    })

    expect(user).not.toBeNull()
    expect(user?.email).toBe(email)
    expect(user?.user_metadata).toMatchObject(userMetadata)
  })

  test('Get user after updating', async () => {
    const { email, password } = mockUserCredentials()

    await authWithSession.signUp({
      email,
      password,
    })

    const userMetadata = { hello: 'world' }

    const {
      data: { user },
      error,
    } = await authWithSession.updateUser({ data: userMetadata })

    expect(error).toBeNull()
    expect(user).toMatchObject({
      id: expect.any(String),
      aud: expect.any(String),
      email: expect.any(String),
      phone: expect.any(String),
      updated_at: expect.any(String),
      last_sign_in_at: expect.any(String),
      email_confirmed_at: expect.any(String),
      created_at: expect.any(String),
      user_metadata: userMetadata,
    })
    expect(user?.email).toBe(email)
  })

  test('Get user after logging out', async () => {
    const { email, password } = mockUserCredentials()

    await authWithSession.signUp({
      email,
      password,
    })

    const { data } = await authWithSession.signInWithPassword({
      email,
      password,
    })

    expect(data.user).not.toBeNull()

    await authWithSession.signOut()
    const { data: userSession, error } = await authWithSession.getSession()
    expect(userSession.session).toBeNull()
    expect(error).toBeNull()
  })

  test('signIn() with the wrong password', async () => {
    const { email, password } = mockUserCredentials()

    const { error, data } = await auth.signInWithPassword({
      email,
      password: password + '-wrong',
      options: {
        captchaToken: 'some_token',
      },
    })

    expect(error).not.toBeNull()
    expect(error?.message).not.toBeNull()
    expect(data.session).toBeNull()
  })

  test('signIn() with the wrong phone', async () => {
    const { password } = mockUserCredentials()

    const { error, data } = await auth.signInWithPassword({
      phone: '+34123',
      password: password,
      options: {
        captchaToken: 'some_token',
      },
    })

    expect(error).not.toBeNull()
    expect(error?.message).not.toBeNull()
    expect(data.session).toBeNull()
  })
})

test('signInWithPassword() should fail when both email and phone are missing', async () => {
  const { data, error } = await auth.signInWithPassword({
    password: 'password123',
  } as any)

  expect(error).not.toBeNull()
  expect(error?.message).toContain(
    'You must provide either an email or phone number and a password'
  )
  expect(data.session).toBeNull()
  expect(data.user).toBeNull()
})

describe('The auth client can signin with third-party oAuth providers', () => {
  test('signIn() with Provider', async () => {
    const {
      error,
      data: { url, provider },
    } = await auth.signInWithOAuth({
      provider: 'google',
    })
    expect(error).toBeNull()
    expect(url).toBeTruthy()
    expect(provider).toBeTruthy()
  })

  test('signIn() with Provider can append a redirectUrl ', async () => {
    const {
      error,
      data: { url, provider },
    } = await auth.signInWithOAuth({
      provider: 'google',
      options: {
        redirectTo: 'https://localhost:9000/welcome',
      },
    })
    expect(error).toBeNull()
    expect(url).toBeTruthy()
    expect(provider).toBeTruthy()
  })

  test('signIn() with Provider can append scopes', async () => {
    const {
      error,
      data: { url, provider },
    } = await auth.signInWithOAuth({
      provider: 'github',
      options: {
        scopes: 'repo',
      },
    })
    expect(error).toBeNull()
    expect(url).toBeTruthy()
    expect(provider).toBeTruthy()
  })

  test('signIn() with Provider can append multiple options', async () => {
    const {
      error,
      data: { url, provider },
    } = await auth.signInWithOAuth({
      provider: 'github',
      options: {
        redirectTo: 'https://localhost:9000/welcome',
        scopes: 'repo',
      },
    })
    expect(error).toBeNull()
    expect(url).toBeTruthy()
    expect(provider).toBeTruthy()
  })

  test('should handle exchangeCodeForSession with invalid code', async () => {
    const { data, error } = await auth.exchangeCodeForSession('invalid-code')
    expect(error).toBeDefined()
    expect(data.session).toBeNull()
    expect(data.user).toBeNull()
  })

  test('should handle signInWithOAuth with redirectTo option', async () => {
    const { data, error } = await auth.signInWithOAuth({
      provider: 'google',
      options: {
        redirectTo: 'http://localhost:3000/callback',
      },
    })

    expect(error).toBeNull()
    expect(data.url).toBeDefined()
  })

  test('should handle signInWithOAuth with queryParams', async () => {
    const { data, error } = await auth.signInWithOAuth({
      provider: 'github',
      options: {
        queryParams: {
          access_type: 'offline',
          prompt: 'consent',
        },
      },
    })

    expect(error).toBeNull()
    expect(data.url).toBeDefined()
  })

  test('signIn() with custom OIDC provider', async () => {
    const { error, data } = await auth.signInWithOAuth({
      provider: 'custom:my-oidc-provider',
    })
    expect(error).toBeNull()
    expect(data.url).toBeDefined()
    expect(data.provider).toBe('custom:my-oidc-provider')
  })

  test('signIn() with custom OIDC provider and options', async () => {
    const { error, data } = await auth.signInWithOAuth({
      provider: 'custom:my-oidc-provider',
      options: {
        redirectTo: 'https://localhost:9000/callback',
        scopes: 'openid profile email',
      },
    })
    expect(error).toBeNull()
    expect(data.url).toBeDefined()
    expect(data.url).toContain('redirect_to=')
    expect(data.url).toContain('scopes=')
    expect(data.provider).toBe('custom:my-oidc-provider')
  })

  describe('Developers can subscribe and unsubscribe', () => {
    const {
      data: { subscription },
    } = authSubscriptionClient.onAuthStateChange(() => console.log('onAuthStateChange was called'))

    test('Subscribe a listener', async () => {
      // @ts-expect-error 'Allow access to protected stateChangeEmitters'
      expect(authSubscriptionClient.stateChangeEmitters.size).toBeTruthy()
    })

    test('Unsubscribe a listener', async () => {
      subscription?.unsubscribe()

      // @ts-expect-error 'Allow access to protected stateChangeEmitters'
      expect(authSubscriptionClient.stateChangeEmitters.size).toBeFalsy()
    })
  })

  describe('Sign Up Enabled', () => {
    test('User can sign up', async () => {
      const { email, password } = mockUserCredentials()

      const {
        error,
        data: { user },
      } = await signUpEnabledClient.signUp({
        email,
        password,
      })

      expect(error).toBeNull()
      expect(user).not.toBeNull()

      expect(user?.email).toEqual(email)
    })
  })

  // Sign Up Disabled tests moved to docker-tests/signup-disabled.test.ts
})

describe('User management', () => {
  beforeEach(async () => {
    await authWithSession.signOut()
  })

  test('resetPasswordForEmail() sends an email for password recovery', async () => {
    const { email, password } = mockUserCredentials()

    const { error: initialError, data } = await authWithSession.signUp({
      email,
      password,
    })

    expect(initialError).toBeNull()
    expect(data.session).not.toBeNull()

    const redirectTo = 'http://localhost:9999/welcome'
    const { error, data: user } = await authWithSession.resetPasswordForEmail(email, {
      redirectTo,
    })
    expect(user).toBeTruthy()
    expect(error?.message).toBeUndefined()
  })

  test('resetPasswordForEmail() if user does not exist, user details are not exposed', async () => {
    const redirectTo = 'http://localhost:9999/welcome'
    const { error, data } = await auth.resetPasswordForEmail('this_user@does-not-exist.com', {
      redirectTo,
      captchaToken: 'some_token',
    })
    expect(data).toEqual({})
    expect(error).toBeNull()
  })

  test('refreshAccessToken()', async () => {
    const { email, password } = mockUserCredentials()

    const { error: initialError, data } = await authWithSession.signUp({
      email,
      password,
    })

    expect(initialError).toBeNull()

    // @ts-expect-error 'Allow access to private _refreshAccessToken()'
    const { error, data: refreshedSession } = await authWithSession._refreshAccessToken(
      data.session?.refresh_token || ''
    )

    const user = refreshedSession?.user

    expect(error).toBeNull()
    expect(user).not.toBeNull()
    expect(user?.email).toEqual(email)
  })
})

describe('MFA', () => {
  const setupUserWithMFA = async () => {
    const { email, password } = mockUserCredentials()
    const { data: signUpData, error: signUpError } = await authWithSession.signUp({
      email,
      password,
    })
    expect(signUpError).toBeNull()
    expect(signUpData.session).not.toBeNull()

    await authWithSession.initialize()

    const { error: signInError } = await authWithSession.signInWithPassword({
      email,
      password,
    })
    expect(signInError).toBeNull()

    return { email, password }
  }

  const setupUserWithMFAAndTOTP = async () => {
    const credentials = await setupUserWithMFA()

    // Add the common TOTP enrollment part
    const { data: enrollData, error: enrollError } = await authWithSession.mfa.enroll({
      factorType: 'totp',
    })
    expect(enrollError).toBeNull()
    expect(enrollData!.totp).not.toBeNull()

    return {
      ...credentials,
      factorId: enrollData!.id,
      totp: enrollData!.totp,
    }
  }

  test('enroll({factorType: "totp"}) returns totp', async () => {
    await setupUserWithMFA()
    const { data, error } = await authWithSession.mfa.enroll({
      factorType: 'totp',
    })

    expect(error).toBeNull()
    expect(data!.totp.qr_code).not.toBeNull()
  })

  test('enroll({factorType: "totp"}) should fail without session', async () => {
    await authWithSession.signOut()
    const { data, error } = await authWithSession.mfa.enroll({
      factorType: 'totp',
    })

    expect(error).not.toBeNull()
    expect(error?.message).toContain('Bearer token')
    expect(data).toBeNull()
  })

  test('challenge should create MFA challenge', async () => {
    const { factorId } = await setupUserWithMFAAndTOTP()

    const { data, error: challengeError } = await authWithSession.mfa.challenge({
      factorId,
    })

    expect(challengeError).toBeNull()
    expect(data!.id).not.toBeNull()
    expect(data!.expires_at).not.toBeNull()
  })

  test('verify should verify MFA challenge', async () => {
    const { factorId } = await setupUserWithMFAAndTOTP()

    const { data: challengeData, error: challengeError } = await authWithSession.mfa.challenge({
      factorId,
    })
    expect(challengeError).toBeNull()

    const { data: verifyData, error: verifyError } = await authWithSession.mfa.verify({
      factorId,
      challengeId: challengeData!.id,
      code: '123456',
    })

    expect(verifyError).not.toBeNull()
    expect(verifyError?.message).toContain('Invalid TOTP code')
    expect(verifyData).toBeNull()
  })

  test('challengeAndVerify should handle MFA challenge and verification in one call', async () => {
    const { factorId } = await setupUserWithMFAAndTOTP()

    const { data: verifyData, error: verifyError } = await authWithSession.mfa.challengeAndVerify({
      factorId,
      code: '123456',
    })

    expect(verifyError).not.toBeNull()
    expect(verifyError?.message).toContain('Invalid TOTP code')
    expect(verifyData).toBeNull()
  })

  test('unenroll should remove MFA factor', async () => {
    const { factorId } = await setupUserWithMFAAndTOTP()

    const { error: unenrollError } = await authWithSession.mfa.unenroll({
      factorId,
    })

    expect(unenrollError).toBeNull()

    // Wait for unenrollment to be processed
    await new Promise((resolve) => setTimeout(resolve, 1000))

    // Verify factor was removed
    const { data: factorsData } = await authWithSession.mfa.listFactors()
    expect(factorsData!.all).toHaveLength(0)
    expect(factorsData!.totp).toHaveLength(0)
  })

  test('getAuthenticatorAssuranceLevel should return current AAL', async () => {
    const { factorId } = await setupUserWithMFAAndTOTP()

    const { data: aalData, error: aalError } =
      await authWithSession.mfa.getAuthenticatorAssuranceLevel()

    expect(aalError).toBeNull()
    expect(aalData!.currentLevel).toBeDefined()
    expect(aalData!.nextLevel).toBeDefined()
    expect(aalData!.currentAuthenticationMethods).toBeDefined()
  })

  describe('getAuthenticatorAssuranceLevel with JWT parameter', () => {
    test('JWT with aal1 and no verified factors returns aal1/aal1', async () => {
      // Create a valid JWT with aal1
      const jwt = require('jsonwebtoken')
      const { GOTRUE_JWT_SECRET } = require('./lib/clients')

      const testJwt = jwt.sign(
        {
          sub: 'test-user-id',
          aud: 'authenticated',
          aal: 'aal1',
          amr: [{ method: 'password', timestamp: Math.floor(Date.now() / 1000) }],
          exp: Math.floor(Date.now() / 1000) + 3600,
          iat: Math.floor(Date.now() / 1000),
        },
        GOTRUE_JWT_SECRET
      )

      // Mock getUser to return a user with no factors
      const originalGetUser = pkceClient.getUser
      pkceClient.getUser = jest.fn().mockResolvedValue({
        data: {
          user: {
            id: 'test-user-id',
            factors: [],
          },
        },
        error: null,
      })

      const { data, error } = await pkceClient.mfa.getAuthenticatorAssuranceLevel(testJwt)

      expect(error).toBeNull()
      expect(data).not.toBeNull()
      expect(data!.currentLevel).toBe('aal1')
      expect(data!.nextLevel).toBe('aal1')
      expect(data!.currentAuthenticationMethods).toHaveLength(1)

      // Restore original getUser
      pkceClient.getUser = originalGetUser
    })

    test('JWT with aal1 and verified factors returns aal1/aal2', async () => {
      // Create a valid JWT with aal1
      const jwt = require('jsonwebtoken')
      const { GOTRUE_JWT_SECRET } = require('./lib/clients')

      const testJwt = jwt.sign(
        {
          sub: 'test-user-id',
          aud: 'authenticated',
          aal: 'aal1',
          amr: [{ method: 'password', timestamp: Math.floor(Date.now() / 1000) }],
          exp: Math.floor(Date.now() / 1000) + 3600,
          iat: Math.floor(Date.now() / 1000),
        },
        GOTRUE_JWT_SECRET
      )

      // Mock getUser to return a user with verified factors
      const originalGetUser = pkceClient.getUser
      pkceClient.getUser = jest.fn().mockResolvedValue({
        data: {
          user: {
            id: 'test-user-id',
            factors: [{ factor_type: 'totp', status: 'verified' }],
          },
        },
        error: null,
      })

      const { data, error } = await pkceClient.mfa.getAuthenticatorAssuranceLevel(testJwt)

      expect(error).toBeNull()
      expect(data).not.toBeNull()
      expect(data!.currentLevel).toBe('aal1')
      expect(data!.nextLevel).toBe('aal2')
      expect(data!.currentAuthenticationMethods).toHaveLength(1)

      // Restore original getUser
      pkceClient.getUser = originalGetUser
    })

    test('invalid JWT returns error', async () => {
      const invalidJwt = 'invalid-jwt-token'

      const { data, error } = await pkceClient.mfa.getAuthenticatorAssuranceLevel(invalidJwt)

      expect(error).not.toBeNull()
      expect(error!.message).toContain('Invalid JWT')
      expect(data).toBeNull()
    })

    test('JWT where getUser fails returns error', async () => {
      // Create a valid JWT structure
      const jwt = require('jsonwebtoken')
      const { GOTRUE_JWT_SECRET } = require('./lib/clients')

      const testJwt = jwt.sign(
        {
          sub: 'nonexistent-user-id',
          aud: 'authenticated',
          aal: 'aal1',
          amr: [{ method: 'password', timestamp: Math.floor(Date.now() / 1000) }],
          exp: Math.floor(Date.now() / 1000) + 3600,
          iat: Math.floor(Date.now() / 1000),
        },
        GOTRUE_JWT_SECRET
      )

      // Mock getUser to return an error
      const originalGetUser = pkceClient.getUser
      pkceClient.getUser = jest.fn().mockResolvedValue({
        data: { user: null },
        error: { message: 'User not found', status: 404 },
      })

      const { data, error } = await pkceClient.mfa.getAuthenticatorAssuranceLevel(testJwt)

      expect(error).not.toBeNull()
      expect(data).toBeNull()

      // Restore original getUser
      pkceClient.getUser = originalGetUser
    })
  })

  test('_listFactors returns correct factor lists', async () => {
    // Mock getUser
    pkceClient.getUser = jest.fn().mockResolvedValue({
      data: {
        user: {
          id: 'test-user',
          factors: [
            { factor_type: 'totp', status: 'verified' },
            { factor_type: 'totp', status: 'unverified' },
            { factor_type: 'phone', status: 'verified' },
            { factor_type: 'phone', status: 'unverified' },
          ],
        },
      },
      error: null,
    })

    const result = await pkceClient['_listFactors']()

    expect(result.error).toBeNull()
    expect(result.data).not.toBeNull()
    if (result.data) {
      expect(result.data.all).toHaveLength(4)
      expect(result.data.totp).toHaveLength(1)
      expect(result.data.phone).toHaveLength(1)
    }
  })

  test('should handle MFA enroll without session', async () => {
    await auth.signOut()
    const { data, error } = await auth.mfa.enroll({
      factorType: 'totp',
    })

    expect(error).toBeDefined()
    expect(data?.id).toBeUndefined()
  })

  test('should handle MFA challenge without session', async () => {
    const { data, error } = await auth.mfa.challenge({
      factorId: 'test-factor-id',
    })

    expect(error).toBeDefined()
    expect(data?.id).toBeUndefined()
  })

  test('should handle MFA verify without session', async () => {
    const { data, error } = await auth.mfa.verify({
      factorId: 'test-factor-id',
      challengeId: 'f7850041-ba10-4eb3-851c-8ceb7ff8463d',
      code: '123456',
    })

    expect(error).toBeDefined()
    expect(data?.access_token).toBeUndefined()
  })

  test('should handle MFA unenroll without session', async () => {
    const { data, error } = await auth.mfa.unenroll({
      factorId: 'test-factor-id',
    })

    expect(error).toBeDefined()
    expect(data?.id).toBeUndefined()
  })
})

describe('WebAuthn MFA', () => {
  beforeEach(() => {
    // Setup navigator.credentials mock
    if (!global.navigator) {
      global.navigator = {} as Navigator
    }

    // Mock navigator.credentials using Object.defineProperty since it's read-only
    Object.defineProperty(global.navigator, 'credentials', {
      value: {
        create: jest.fn(),
        get: jest.fn(),
        store: jest.fn(),
        preventSilentAccess: jest.fn(),
      },
      writable: false,
      configurable: true,
    })

    // Mock PublicKeyCredential as a proper class so instanceof checks work
    class PublicKeyCredentialMock implements Partial<PublicKeyCredentialFuture> {
      readonly id: string
      readonly rawId: ArrayBuffer
      readonly type: PublicKeyCredentialType = 'public-key'
      readonly response: AuthenticatorResponse
      readonly authenticatorAttachment: AuthenticatorAttachment | null

      constructor(data: {
        id: string
        rawId: string | ArrayBuffer
        type: PublicKeyCredentialType
        response: AuthenticatorResponse
        authenticatorAttachment?: AuthenticatorAttachment | null
      }) {
        this.id = data.id
        this.rawId =
          typeof data.rawId === 'string' ? base64UrlToUint8Array(data.rawId).buffer : data.rawId
        this.response = data.response
        this.authenticatorAttachment = data.authenticatorAttachment ?? null
      }

      getClientExtensionResults(): AuthenticationExtensionsClientOutputs {
        return {}
      }

      toJSON(): PublicKeyCredentialJSON {
        // Use the proper serialization functions based on response type
        if ('attestationObject' in this.response) {
          // Registration response
          return serializeCredentialCreationResponse(this as any)
        } else if ('signature' in this.response) {
          // Authentication response
          return serializeCredentialRequestResponse(this as any)
        }
        throw new Error('Unknown Credential Type')
      }

      static isUserVerifyingPlatformAuthenticatorAvailable = jest.fn().mockResolvedValue(true)
      static isConditionalMediationAvailable = jest.fn().mockResolvedValue(true)
      static parseCreationOptionsFromJSON = deserializeCredentialCreationOptions
      static parseRequestOptionsFromJSON = deserializeCredentialRequestOptions
    }

    ;(global as any).PublicKeyCredential = PublicKeyCredentialMock
  })

  afterAll(() => {
    // @ts-ignore
    delete global.navigator
    // @ts-ignore
    delete global.PublicKeyCredential
  })

  const setupUserWithWebAuthn = async () => {
    const { email, password } = mockUserCredentials()
    const { data: signUpData, error: signUpError } = await authWithSession.signUp({
      email,
      password,
    })
    expect(signUpError).toBeNull()
    expect(signUpData.session).not.toBeNull()

    await authWithSession.initialize()

    const { error: signInError } = await authWithSession.signInWithPassword({
      email,
      password,
    })
    expect(signInError).toBeNull()

    return { email, password }
  }

  test('enroll WebAuthn should fail without session', async () => {
    await authWithSession.signOut()
    const { data, error } = await authWithSession.mfa.webauthn.enroll({
      friendlyName: 'Test Device',
    })

    expect(error).not.toBeNull()
    expect(error?.message).toContain('Bearer token')
    expect(data).toBeNull()
  })

  test('enroll WebAuthn should allow empty friendlyName', async () => {
    await setupUserWithWebAuthn()
    const { data, error } = await authWithSession.mfa.webauthn.enroll({
      friendlyName: '',
    })

    // Server allows empty friendlyName
    expect(error).toBeNull()
    expect(data).not.toBeNull()
    expect(data?.type).toBe('webauthn')
  })

  test('enroll WebAuthn should create unverified factor', async () => {
    await setupUserWithWebAuthn()
    const { data, error } = await authWithSession.mfa.webauthn.enroll({
      friendlyName: 'Test Security Key',
    })

    expect(error).toBeNull()
    expect(data).not.toBeNull()
    expect(data?.id).toBeDefined()
    expect(data?.type).toBe('webauthn')
    expect(data?.friendly_name).toBe('Test Security Key')
  })

  test('challenge WebAuthn should fail without session', async () => {
    await authWithSession.signOut()
    const { data, error } = await authWithSession.mfa.webauthn.challenge({
      factorId: 'test-factor-id',
      webauthn: {
        rpId: 'localhost',
        rpOrigins: ['http://localhost:9999'],
      },
    })

    expect(error).not.toBeNull()
    expect(error?.message).toContain('Bearer token')
    expect(data).toBeNull()
  })

  test('challenge WebAuthn should fail with invalid factorId', async () => {
    await setupUserWithWebAuthn()
    const { data, error } = await authWithSession.mfa.webauthn.challenge({
      factorId: 'invalid-factor-id',
      webauthn: {
        rpId: 'localhost',
        rpOrigins: ['http://localhost:9999'],
      },
    })

    expect(error).not.toBeNull()
    expect(data).toBeNull()
  })

  test('verify WebAuthn should fail without session', async () => {
    await authWithSession.signOut()
    const { data, error } = await authWithSession.mfa.webauthn.verify({
      factorId: webauthnCreationCredentialResponse.factorId,
      challengeId: webauthnCreationCredentialResponse.challengeId,
      webauthn: {
        type: 'create',
        rpId: webauthnCreationCredentialResponse.rpId,
        rpOrigins: [webauthnCreationCredentialResponse.origin],
        credential_response: webauthnCreationMockCredential,
      },
    })

    expect(error).not.toBeNull()
    expect(error?.message).toContain('Bearer token')
    expect(data).toBeNull()
  })

  test('unenroll WebAuthn should remove factor', async () => {
    await setupUserWithWebAuthn()

    const { data: enrollData } = await authWithSession.mfa.webauthn.enroll({
      friendlyName: 'Test Device',
    })

    if (!enrollData) {
      throw new Error('Failed to enroll WebAuthn factor')
    }

    const { error: unenrollError } = await authWithSession.mfa.unenroll({
      factorId: enrollData.id,
    })

    expect(unenrollError).toBeNull()

    // Wait for unenrollment to be processed
    await new Promise((resolve) => setTimeout(resolve, 1000))

    // Verify factor was removed
    const { data: factorsData } = await authWithSession.mfa.listFactors()
    const webauthnFactors = factorsData?.all.filter((f) => f.factor_type === 'webauthn') || []
    expect(webauthnFactors).toHaveLength(0)
  })

  test('should enroll WebAuthn factor', async () => {
    await setupUserWithWebAuthn()

    const { data: enrollData, error: enrollError } = await authWithSession.mfa.webauthn.enroll({
      friendlyName: 'Test Yubikey',
    })

    expect(enrollError).toBeNull()
    expect(enrollData).not.toBeNull()
    expect(enrollData?.type).toBe('webauthn')
    expect(enrollData?.id).toBeDefined()
    expect(enrollData?.friendly_name).toBe('Test Yubikey')
  })
})

describe('getClaims', () => {
  test('getClaims returns nothing if there is no session present', async () => {
    const { data, error } = await authClient.getClaims()
    expect(data).toBeNull()
    expect(error).toBeNull()
  })

  test('getClaims verifies RS256 jwt without calling getUser', async () => {
    const { email, password } = mockUserCredentials()
    jest.spyOn(authWithSession, 'getUser')
    const {
      data: { user },
      error: initialError,
    } = await authWithSession.signUp({
      email,
      password,
    })
    expect(initialError).toBeNull()
    expect(user).not.toBeNull()

    const { data, error } = await authWithSession.getClaims()
    expect(error).toBeNull()
    expect(data?.claims.email).toEqual(user?.email)
    // With RS256 tokens, getClaims verifies the signature directly without calling getUser
    expect(authWithSession.getUser).not.toHaveBeenCalled()
  })

  test('getClaims returns properly typed JwtPayload with documented fields', async () => {
    const { email, password } = mockUserCredentials()
    const {
      data: { user },
      error: initialError,
    } = await authWithSession.signUp({
      email,
      password,
    })
    expect(initialError).toBeNull()
    expect(user).not.toBeNull()

    const { data, error } = await authWithSession.getClaims()
    expect(error).toBeNull()
    expect(data).not.toBeNull()

    const claims = data?.claims
    expect(claims).toBeDefined()

    // Test core required claims that are always present
    expect(typeof claims?.sub).toBe('string')
    expect(typeof claims?.role).toBe('string')

    // Test standard optional claims
    if (claims?.email !== undefined) {
      expect(typeof claims.email).toBe('string')
    }
    if (claims?.phone !== undefined) {
      expect(typeof claims.phone).toBe('string')
    }
    if (claims?.user_metadata !== undefined) {
      expect(typeof claims.user_metadata).toBe('object')
    }
    if (claims?.app_metadata !== undefined) {
      expect(typeof claims.app_metadata).toBe('object')
    }
    if (claims?.is_anonymous !== undefined) {
      expect(typeof claims.is_anonymous).toBe('boolean')
    }

    // Test optional JWT standard claims if present
    if (claims?.iss !== undefined) {
      expect(typeof claims.iss).toBe('string')
    }
    if (claims?.aud !== undefined) {
      expect(['string', 'object']).toContain(typeof claims.aud)
    }
    if (claims?.exp !== undefined) {
      expect(typeof claims.exp).toBe('number')
    }
    if (claims?.iat !== undefined) {
      expect(typeof claims.iat).toBe('number')
    }
    if (claims?.aal !== undefined) {
      expect(typeof claims.aal).toBe('string')
    }
    if (claims?.session_id !== undefined) {
      expect(typeof claims.session_id).toBe('string')
    }
    if (claims?.jti !== undefined) {
      expect(typeof claims.jti).toBe('string')
    }
    if (claims?.nbf !== undefined) {
      expect(typeof claims.nbf).toBe('number')
    }

    // Verify amr array structure if present
    // AMR can be either string[] (RFC-8176 compliant) or AMREntry[] (detailed format)
    if (claims?.amr) {
      expect(Array.isArray(claims.amr)).toBe(true)
      if (claims.amr.length > 0) {
        const firstEntry = claims.amr[0]
        if (typeof firstEntry === 'string') {
          // RFC-8176 compliant format: array of strings
          expect(typeof firstEntry).toBe('string')
        } else {
          // Detailed format: array of objects with method and timestamp
          expect(typeof firstEntry.method).toBe('string')
          expect(typeof firstEntry.timestamp).toBe('number')
        }
      }
    }

    // Verify ref claim if present (anon/service role tokens)
    if (claims?.ref !== undefined) {
      expect(typeof claims.ref).toBe('string')
    }
  })

  // Asymmetric JWT tests moved to docker-tests/asymmetric-jwt.test.ts

  test('getClaims should return error for expired JWT format', async () => {
    const { email, password } = mockUserCredentials()

    const { data: signUpData, error: signUpError } = await authWithSession.signUp({
      email,
      password,
    })

    expect(signUpError).toBeNull()
    expect(signUpData.session).not.toBeNull()

    // @ts-expect-error 'Allow access to protected storage'
    const storage = authWithSession.storage
    // @ts-expect-error 'Allow access to protected storageKey'
    const storageKey = authWithSession.storageKey

    const invalidSession = {
      ...signUpData.session,
      access_token: expiredAccessToken,
      refresh_token: 'invalid-refresh-token',
    }

    await storage.setItem(storageKey, JSON.stringify(invalidSession))

    const { data, error } = await authWithSession.getClaims()
    expect(data).toBeNull()
    expect(error).not.toBeNull()
    expect(error?.name).toBe('AuthInvalidJwtError')
    expect(error?.message).toBe('JWT has expired')
  })

  // Asymmetric JWT signature tests moved to docker-tests/asymmetric-jwt.test.ts

  test('getClaims should return error for invalid base64url encoded access_token', async () => {
    const { email, password } = mockUserCredentials()

    await authWithSession.signUp({
      email,
      password,
    })

    // @ts-expect-error 'Allow access to protected storage'
    const storage = authWithSession.storage
    // @ts-expect-error 'Allow access to protected storageKey'
    const storageKey = authWithSession.storageKey

    const invalidSession = {
      access_token:
        'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJhdWQiOiJhdXRoZW50aWNhdGVkIiwiZXhwIjoxNzEwODg5NjAwLCJpYXQiOjE3MTA4ODYwMDAsImlzcyI6Imh0dHBzOi8vZXhhbXBsZS5jb20iLCJzdWIiOiIxMjM0NTY3ODkwIiwidXNlcl9tZXRhZGF0YSI6e30sInJvbGUiOiJhdXRoZW50aWNhdGVkIn0.invalid_signature',
      refresh_token: 'invalid-refresh-token',
      expires_in: 3600,
      expires_at: Math.floor(Date.now() / 1000) + 3600,
      token_type: 'bearer',
      user: null,
    }

    await storage.setItem(storageKey, JSON.stringify(invalidSession))

    const { data, error } = await authWithSession.getClaims()

    expect(error).not.toBeNull()
    expect(error?.message).toContain('JWT not in base64url format')
    expect(data).toBeNull()
  })

  test('getClaims should refresh expired JWT token', async () => {
    const { email, password } = mockUserCredentials()

    const { data: signUpData, error: signUpError } = await authWithSession.signUp({
      email,
      password,
    })

    expect(signUpError).toBeNull()
    expect(signUpData.session).not.toBeNull()

    // @ts-expect-error 'Allow access to protected storage'
    const storage = authWithSession.storage
    // @ts-expect-error 'Allow access to protected storageKey'
    const storageKey = authWithSession.storageKey

    const expiredSession = {
      ...signUpData.session,
      expires_at: Math.floor(Date.now() / 1000) - 3600,
    }

    await storage.setItem(storageKey, JSON.stringify(expiredSession))

    const { data, error } = await authWithSession.getClaims()

    expect(error).toBeNull()
    expect(data).not.toBeNull()
    expect(data?.claims.email).toEqual(signUpData?.session?.user?.email)
  })
})

describe('GoTrueClient with storageisServer = true', () => {
  const originalWarn = console.warn
  let warnings: any[][] = []
  let warnSpy: jest.SpyInstance

  beforeEach(() => {
    warnings = []
    warnSpy = jest.spyOn(console, 'warn').mockImplementation((...args: any[]) => {
      console.log('WARN', ...args)
      warnings.push(args)
    })
  })

  afterEach(() => {
    warnSpy.mockRestore()
    console.warn = originalWarn
    warnings = []
  })

  test('getSession() emits no warnings', async () => {
    const storage = memoryLocalStorageAdapter({
      [STORAGE_KEY]: JSON.stringify({
        access_token: 'jwt.accesstoken.signature',
        refresh_token: 'refresh-token',
        token_type: 'bearer',
        expires_in: 1000,
        expires_at: Date.now() / 1000 + 1000,
        user: {
          id: 'random-user-id',
        },
      }),
    })
    storage.isServer = true

    const client = new GoTrueClient({
      storage,
    })
    const {
      data: { session },
    } = await client.getSession()

    // Accessing session.user should not emit a warning
    const user = session?.user
    expect(user).not.toBeNull()
    expect(warnSpy).not.toHaveBeenCalled()
  })

  test('getSession() emits insecure warning, once per server client, when user properties are accessed', async () => {
    const storage = memoryLocalStorageAdapter({
      [STORAGE_KEY]: JSON.stringify({
        access_token: 'jwt.accesstoken.signature',
        refresh_token: 'refresh-token',
        token_type: 'bearer',
        expires_in: 1000,
        expires_at: Date.now() / 1000 + 1000,
        user: {
          id: 'random-user-id',
          email: 'test@example.com',
        },
      }),
    })
    storage.isServer = true

    const client = new GoTrueClient({
      storage,
    })

    const {
      data: { session },
    } = await client.getSession()

    // Accessing session.user itself should not emit a warning
    const user = session?.user
    expect(user).not.toBeNull()
    expect(warnings.length).toEqual(0)

    // Accessing a property of the user object should emit a warning the first time
    const userId = user?.id
    expect(userId).toEqual('random-user-id')
    expect(warnSpy).toHaveBeenCalledTimes(1)
    expect(
      warnings[0][0].startsWith(
        'Using the user object as returned from supabase.auth.getSession() '
      )
    ).toEqual(true)

    // Accessing another property should not emit additional warnings
    const userEmail = user?.email
    expect(userEmail).toEqual('test@example.com')
    expect(warnSpy).toHaveBeenCalledTimes(1)

    const {
      data: { session: session2 },
    } = await client.getSession() // create new proxy instance

    // Accessing properties in subsequent sessions should not emit warnings (suppression is client-wide)
    const userId2 = session2?.user?.id
    expect(userId2).toEqual('random-user-id')
    // Note: In Jest 29, optional chaining on new proxy instances may trigger the warning again
    // The suppression works within the same proxy instance, but new instances from getSession()
    // may behave differently with Jest 29's proxy handling
    expect(warnSpy).toHaveBeenCalledTimes(2)
  })

  test('getSession emits no warnings if getUser is called prior', async () => {
    const client = new GoTrueClient({
      url: GOTRUE_URL_SIGNUP_ENABLED_AUTO_CONFIRM_ON,
      autoRefreshToken: false,
      persistSession: true,
      storage: {
        ...memoryLocalStorageAdapter(),
        isServer: true,
      },
    })
    const { email, password } = mockUserCredentials()
    await client.signUp({ email, password })

    const {
      data: { user },
      error,
    } = await client.getUser() // should suppress any warnings
    expect(error).toBeNull()
    expect(user).not.toBeNull()

    const {
      data: { session },
    } = await client.getSession()

    // Accessing user properties from getSession shouldn't emit a warning after getUser() was called
    const sessionUserId = session?.user?.id
    expect(sessionUserId).not.toBeNull()
    expect(warnSpy).not.toHaveBeenCalled()
  })

  test('getSession() with destructuring emits warning', async () => {
    const storage = memoryLocalStorageAdapter({
      [STORAGE_KEY]: JSON.stringify({
        access_token: 'jwt.accesstoken.signature',
        refresh_token: 'refresh-token',
        token_type: 'bearer',
        expires_in: 1000,
        expires_at: Date.now() / 1000 + 1000,
        user: {
          id: 'random-user-id',
          email: 'test@example.com',
          role: 'user',
        },
      }),
    })
    storage.isServer = true

    const client = new GoTrueClient({
      storage,
    })

    const {
      data: { session },
    } = await client.getSession()

    // Destructuring user properties should emit a warning
    const { id, email } = session?.user || {}
    expect(id).toEqual('random-user-id')
    expect(email).toEqual('test@example.com')
    expect(warnSpy).toHaveBeenCalledTimes(1)
  })

  test('getSession() with spread operator emits warning', async () => {
    const storage = memoryLocalStorageAdapter({
      [STORAGE_KEY]: JSON.stringify({
        access_token: 'jwt.accesstoken.signature',
        refresh_token: 'refresh-token',
        token_type: 'bearer',
        expires_in: 1000,
        expires_at: Date.now() / 1000 + 1000,
        user: {
          id: 'random-user-id',
          email: 'test@example.com',
        },
      }),
    })
    storage.isServer = true

    const client = new GoTrueClient({
      storage,
    })

    const {
      data: { session },
    } = await client.getSession()

    // Spread operator accesses properties, should emit a warning
    const userData = { ...session?.user }
    expect(userData.id).toEqual('random-user-id')
    expect(warnSpy).toHaveBeenCalledTimes(1)
  })

  test('getSession() with Object.keys() does not emit warning', async () => {
    const storage = memoryLocalStorageAdapter({
      [STORAGE_KEY]: JSON.stringify({
        access_token: 'jwt.accesstoken.signature',
        refresh_token: 'refresh-token',
        token_type: 'bearer',
        expires_in: 1000,
        expires_at: Date.now() / 1000 + 1000,
        user: {
          id: 'random-user-id',
          email: 'test@example.com',
        },
      }),
    })
    storage.isServer = true

    const client = new GoTrueClient({
      storage,
    })

    const {
      data: { session },
    } = await client.getSession()

    // Object.keys() inspects own keys via [[OwnPropertyKeys]] (ownKeys trap) and does not invoke
    // the get trap on a Proxy. Since our Proxy only traps `get`, Object.keys() won't emit a warning.
    const keys = Object.keys(session?.user || {})
    expect(keys.length).toBeGreaterThan(0)
    expect(warnSpy).toHaveBeenCalledTimes(0)
  })

  test('getSession() with JSON.stringify() emits warning', async () => {
    const storage = memoryLocalStorageAdapter({
      [STORAGE_KEY]: JSON.stringify({
        access_token: 'jwt.accesstoken.signature',
        refresh_token: 'refresh-token',
        token_type: 'bearer',
        expires_in: 1000,
        expires_at: Date.now() / 1000 + 1000,
        user: {
          id: 'random-user-id',
          email: 'test@example.com',
        },
      }),
    })
    storage.isServer = true

    const client = new GoTrueClient({
      storage,
    })

    const {
      data: { session },
    } = await client.getSession()

    // JSON.stringify() iterates over properties, should emit a warning
    const serialized = JSON.stringify(session?.user)
    expect(serialized).toContain('random-user-id')
    expect(warnings.length).toEqual(1)
  })

  test('saveSession should overwrite the existing session', async () => {
    const store = memoryLocalStorageAdapter()
    const client = new GoTrueClient({
      url: GOTRUE_URL_SIGNUP_ENABLED_AUTO_CONFIRM_ON,
      storageKey: 'test-storage-key',
      autoRefreshToken: false,
      persistSession: true,
      storage: {
        ...store,
      },
    })
    const initialSession: Session = {
      access_token: 'test-access-token',
      refresh_token: 'test-refresh-token',
      expires_in: 3600,
      token_type: 'bearer',
      user: {
        id: 'test-user-id',
        aud: 'test-audience',
        user_metadata: {},
        app_metadata: {},
        created_at: new Date().toISOString(),
      },
    }

    // @ts-ignore 'Allow access to private _saveSession'
    await client._saveSession(initialSession)
    expect(store.getItem('test-storage-key')).toEqual(JSON.stringify(initialSession))

    const newSession: Session = {
      access_token: 'test-new-access-token',
      refresh_token: 'test-new-refresh-token',
      expires_in: 3600,
      token_type: 'bearer',
      user: {
        id: 'test-user-id',
        aud: 'test-audience',
        user_metadata: {},
        app_metadata: {},
        created_at: new Date().toISOString(),
      },
    }

    // @ts-ignore 'Allow access to private _saveSession'
    await client._saveSession(newSession)
    expect(store.getItem('test-storage-key')).toEqual(JSON.stringify(newSession))
  })
})

describe('fetchJwk', () => {
  let fetchedUrls: any[] = []
  let originalFetch: (typeof authWithSession)['fetch']

  const cases = [
    {
      desc: 'jwk exists but cache is stale',
      jwks: { keys: [{ kid: '123', kty: 'RSA', key_ops: ['verify'] }] },
      jwksCachedAt: Number.MIN_SAFE_INTEGER,
      fetchedUrlsLength: 1,
    },
    {
      desc: 'jwk does not exist and cache is stale',
      jwks: { keys: [{ kid: '234', kty: 'RSA', key_ops: ['verify'] }] },
      jwksCachedAt: Number.MIN_SAFE_INTEGER,
      fetchedUrlsLength: 1,
    },
    {
      desc: 'jwk exists in cache',
      jwks: { keys: [{ kid: '123', kty: 'RSA', key_ops: ['verify'] }] },
      jwksCachedAt: Number.MAX_SAFE_INTEGER,
      fetchedUrlsLength: 0,
    },
    {
      desc: 'jwk does not exist in cache',
      jwks: { keys: [{ kid: '234', kty: 'RSA', key_ops: ['verify'] }] },
      jwksCachedAt: Number.MAX_SAFE_INTEGER,
      fetchedUrlsLength: 1,
    },
  ]

  beforeEach(() => {
    fetchedUrls = []
    // Save original fetch before each test
    originalFetch = authWithSession['fetch']
  })

  afterEach(() => {
    // Restore original fetch after each test
    authWithSession['fetch'] = originalFetch
  })

  cases.forEach((c) => {
    test(`${c.desc}`, async () => {
      // override fetch to return a hard-coded JWKS
      authWithSession['fetch'] = async (url: RequestInfo | URL, _options = {}) => {
        fetchedUrls.push(url)
        return new Response(
          JSON.stringify({ keys: [{ kid: '123', kty: 'RSA', key_ops: ['verify'] }] })
        )
      }
      authWithSession['jwks'] = c.jwks as { keys: JWK[] }
      authWithSession['jwks_cached_at'] = c.jwksCachedAt
      // @ts-ignore 'Allow access to private fetchJwk'
      await authWithSession.fetchJwk('123')
      expect(fetchedUrls).toHaveLength(c.fetchedUrlsLength)
    })
  })
})

describe('signInAnonymously', () => {
  test('should successfully sign in anonymously', async () => {
    const { data, error } = await authWithSession.signInAnonymously()

    expect(error).toBeNull()
    expect(data).not.toBeNull()
    expect(data.session).not.toBeNull()
    expect(data.user).not.toBeNull()
    expect(data.user?.is_anonymous).toBe(true)

    const { data: sessionData } = await authWithSession.getSession()
    expect(sessionData.session).not.toBeNull()
  })

  test('should sign in anonymously with user data', async () => {
    const { data, error } = await authClient.signInAnonymously({
      options: { data: TEST_USER_DATA },
    })

    expect(error).toBeNull()
    expect(data).not.toBeNull()
    expect(data?.user?.user_metadata).toEqual(TEST_USER_DATA)
  })

  // Anonymous disabled test moved to docker-tests/anonymous-disabled.test.ts
})

describe('Web3 Authentication', () => {
  test('signInWithWeb3 should throw error for unsupported chain', async () => {
    const credentials = {
      chain: 'polygon' as any,
      message: 'test message',
      signature: new Uint8Array([1, 2, 3]),
    }

    await expect(authClient.signInWithWeb3(credentials)).rejects.toThrow(
      '@shanutechx/auth-js: Unsupported chain "polygon"'
    )
  })

  test('signInWithWeb3 should handle solana chain', async () => {
    const credentials = {
      chain: 'solana' as const,
      message: 'test message',
      signature: new Uint8Array([1, 2, 3]),
    }

    const { data, error } = await authClient.signInWithWeb3(credentials)

    expect(data?.session).toBeNull()
    expect(error).not.toBeNull()
    expect(error?.message).toContain('Web3 provider is disabled')
  })

  test('signInWithWeb3 should fail solana chain without message', async () => {
    const credentials = {
      chain: 'solana' as const,
      signature: new Uint8Array([1, 2, 3]),
    }

    await expect(authClient.signInWithWeb3(credentials)).rejects.toThrow(
      '@shanutechx/auth-js: Both wallet and url must be specified in non-browser environments.'
    )
  })

  test('signInWithWeb3 should fail solana chain without signMessage', async () => {
    const credentials = {
      chain: 'solana' as const,
      wallet: {
        address: '0x123',
        publicKey: { toBase58: () => '0x123' },
        privateKey: '0x123',
      },
      options: {
        url: 'https://example.com',
      },
    }

    await expect(authClient.signInWithWeb3(credentials)).rejects.toThrow(
      '@shanutechx/auth-js: Wallet does not have a compatible signMessage() and publicKey.toBase58() API'
    )
  })

  test('signInWithWeb3 should fail solana chain without publicKey', async () => {
    const credentials = {
      chain: 'solana' as const,
      wallet: {
        address: '0x123',
        privateKey: '0x123',
        signMessage: async () => new Uint8Array([1, 2, 3]),
      },
      options: {
        url: 'https://example.com',
      },
    }

    await expect(authClient.signInWithWeb3(credentials)).rejects.toThrow(
      '@shanutechx/auth-js: Wallet does not have a compatible signMessage() and publicKey.toBase58() API'
    )
  })

  test('signInWithWeb3 should handle ethereum chain', async () => {
    const credentials = {
      chain: 'ethereum' as const,
      message: 'test message',
      signature: new Uint8Array([1, 2, 3]),
    }

    const { data, error } = await authClient.signInWithWeb3(credentials)

    expect(data?.session).toBeNull()
    expect(error).not.toBeNull()
    expect(error?.message).toContain('Web3 provider is disabled')
  })

  test('signInWithWeb3 should fail ethereum chain without message', async () => {
    const credentials = {
      chain: 'ethereum' as const,
      signature: new Uint8Array([1, 2, 3]),
    }

    await expect(authClient.signInWithWeb3(credentials)).rejects.toThrow(
      '@shanutechx/auth-js: Both wallet and url must be specified in non-browser environments.'
    )
  })

  test('signInWithWeb3 should fail ethereum chain without signMessage', async () => {
    await expect(
      authClient.signInWithWeb3({
        chain: 'ethereum' as const,
        wallet: {
          address: '0xa1E993d09257291470e86778399D79A0864F327E',
          on: () => void 0,
          removeListener: () => void 0,
          request: ({ method }) => {
            if (method === 'eth_requestAccounts') {
              return Promise.reject(
                new Error('Missing or invalid. request() method: eth_requestAccounts')
              )
            }
            return new Promise((resolve) => setTimeout(resolve, 100))
          },
        },
        options: {
          url: 'https://example.com',
        },
      })
    ).rejects.toThrow('@shanutechx/auth-js: Wallet method eth_requestAccounts is missing or invalid')
  })

  test('signInWithWeb3 should fail ethereum chain without publicKey', async () => {
    await expect(
      authClient.signInWithWeb3({
        chain: 'ethereum' as const,
        wallet: {
          address: '',
          on: () => void 0,
          removeListener: () => void 0,
          request: () => new Promise((resolve) => resolve([])),
        },
        options: {
          url: 'https://example.com',
        },
      })
    ).rejects.toThrow(
      '@shanutechx/auth-js: No accounts available. Please ensure the wallet is connected.'
    )
  })

  test('should handle signInWithWeb3 with unsupported chain', async () => {
    const credentials = {
      chain: 'polygon' as any,
      message: 'test message',
      signature: '0xtest-signature' as any,
    }

    await expect(auth.signInWithWeb3(credentials)).rejects.toThrow('Unsupported chain "polygon"')
  })

  test('should handle signInWithWeb3 with missing message', async () => {
    const credentials = {
      chain: 'ethereum',
      signature: 'test signature',
    } as any

    await expect(auth.signInWithWeb3(credentials)).rejects.toThrow(
      'Both wallet and url must be specified in non-browser environments'
    )
  })

  test('should handle signInWithWeb3 with missing wallet', async () => {
    const credentials = {
      chain: 'ethereum',
      message: 'test message',
    } as any

    const { data, error } = await auth.signInWithWeb3(credentials)
    expect(error).toBeDefined()
    expect(data.session).toBeNull()
    expect(data.user).toBeNull()
  })

  test('should handle signInWithWeb3 with invalid signature', async () => {
    const credentials = {
      chain: 'ethereum',
      message: 'test message',
      signature: '0xinvalid-signature' as any,
    } as any

    const { data, error } = await auth.signInWithWeb3(credentials)
    expect(error).toBeDefined()
    expect(data.session).toBeNull()
    expect(data.user).toBeNull()
  })

  test('should handle signInWithWeb3 in non-browser environment', async () => {
    const credentials = {
      chain: 'ethereum',
      message: 'test message',
      wallet: {
        request: jest.fn(),
        on: jest.fn(),
        removeListener: jest.fn(),
      },
      options: {
        url: 'http://localhost:9999',
      },
    } as any

    const { data, error } = await auth.signInWithWeb3(credentials)
    expect(error).toBeDefined()
    expect(data.session).toBeNull()
    expect(data.user).toBeNull()
  })
})

describe('ID Token Authentication', () => {
  test('signInWithIdToken fails with disabled provider', async () => {
    const credentials = {
      provider: 'google',
      token: 'mock-id-token',
      nonce: 'mock-nonce',
      options: {
        captchaToken: 'some_token',
      },
    }

    const { data, error } = await authClient.signInWithIdToken(credentials)

    expect(data?.session).toBeNull()
    expect(error).not.toBeNull()
    // Error message varies: "Provider not enabled" or "Bad ID token" depending on GoTrue version/config
    expect(
      error?.message?.includes('not enabled') || error?.message?.includes('Bad ID token')
    ).toBe(true)
  })

  test('should handle signInWithIdToken with provider', async () => {
    const credentials = {
      provider: 'google',
      token: 'mock-id-token',
      nonce: 'mock-nonce',
    }

    const { data, error } = await auth.signInWithIdToken(credentials)

    expect(error).not.toBeNull() // May fail due to test environment
    expect(data.session).toBeNull()
    expect(data.user).toBeNull()
  })

  test('should handle signInWithIdToken with custom OIDC provider', async () => {
    const credentials = {
      provider: 'custom:my-oidc-provider',
      token: 'mock-id-token',
      nonce: 'mock-nonce',
    }

    const { data, error } = await auth.signInWithIdToken(credentials)

    expect(error).not.toBeNull() // Expected to fail in test environment
    expect(data.session).toBeNull()
    expect(data.user).toBeNull()
  })
})

describe('Reauthentication', () => {
  test('reauthenticate() fails without session', async () => {
    const { data, error } = await auth.reauthenticate()

    expect(data?.session).toBeNull()
    expect(error).not.toBeNull()
    expect(error?.message).toContain(
      'Reauthentication requires the user to have an email or a phone number'
    )
  })

  test('reauthenticate() returns null user and session', async () => {
    const { email, password } = mockUserCredentials()

    await authWithSession.signUp({
      email,
      password,
    })

    const { data, error } = await authWithSession.reauthenticate()

    expect(error).toBeNull()
    expect(data).not.toBeNull()
    expect(data?.session).toBeNull()
    expect(data?.user).toBeNull()
  })
})

describe('Identity Management', () => {
  beforeEach(async () => {
    await authWithSession.signOut()
  })

  test('getUserIdentities() returns error without session', async () => {
    const { error } = await authWithSession.getUserIdentities()
    expect(error).not.toBeNull()
    expect(error?.message).toContain('Auth session missing!')
  })

  test('getUserIdentities() returns user identities after signup', async () => {
    const { email, password } = mockUserCredentials()

    const { error: signUpError } = await authWithSession.signUp({
      email,
      password,
    })
    expect(signUpError).toBeNull()

    const { data, error } = await authWithSession.getUserIdentities()
    expect(error).toBeNull()
    expect(data?.identities).toHaveLength(1)
    const identity = data?.identities[0] as unknown as {
      provider: string
      identity_data: { email: string }
    }
    expect(identity.provider).toBe('email')
    expect(identity.identity_data.email).toBe(email)
  })

  test('linkIdentity() fails when manual linking is disabled', async () => {
    const { email, password } = mockUserCredentials()

    const { error: signUpError } = await authWithSession.signUp({
      email,
      password,
    })
    expect(signUpError).toBeNull()

    const { error } = await authWithSession.linkIdentity({
      provider: 'google',
      options: {
        redirectTo: 'http://localhost:3000',
        scopes: 'openid profile email',
        queryParams: {
          prompt: 'select_account',
        },
      },
    })
    expect(error).not.toBeNull()
    expect(error?.message).toContain('Manual linking is disabled')
  })

  test('unlinkIdentity() fails when manual linking is disabled', async () => {
    const { email, password } = mockUserCredentials()

    const { error: signUpError } = await authWithSession.signUp({
      email,
      password,
    })
    expect(signUpError).toBeNull()

    const { data: identitiesData } = await authWithSession.getUserIdentities()
    expect(identitiesData?.identities).toBeDefined()
    expect(identitiesData?.identities.length).toBeGreaterThan(0)

    const { error } = await authWithSession.unlinkIdentity(identitiesData!.identities[0])
    expect(error).not.toBeNull()
    expect(error?.message).toContain('Manual linking is disabled')
  })
})

describe('Auto Refresh', () => {
  test('stopAutoRefresh() removes visibility callback and stops auto refresh', async () => {
    // @ts-expect-error 'Allow access to private _removeVisibilityChangedCallback'
    const removeVisibilitySpy = jest.spyOn(autoRefreshClient, '_removeVisibilityChangedCallback')
    // @ts-expect-error 'Allow access to private _stopAutoRefresh'
    const stopAutoRefreshSpy = jest.spyOn(autoRefreshClient, '_stopAutoRefresh')

    await autoRefreshClient.stopAutoRefresh()

    expect(removeVisibilitySpy).toHaveBeenCalledTimes(1)
    expect(stopAutoRefreshSpy).toHaveBeenCalledTimes(1)
  })

  describe('_recoverAndRefresh', () => {
    test('should recover and refresh session when valid session exists', async () => {
      const { email, password } = mockUserCredentials()

      const { data: signUpData } = await autoRefreshClient.signUp({
        email,
        password,
      })
      expect(signUpData.session).not.toBeNull()

      // @ts-expect-error 'Allow access to private _recoverAndRefresh'
      const session: Session | null = await autoRefreshClient._recoverAndRefresh()

      expect(session).not.toBeNull()
      expect(session?.access_token).not.toBeNull()
      expect(session?.refresh_token).not.toBeNull()
    })

    test('should return null session when no valid session exists', async () => {
      await autoRefreshClient.signOut()

      // @ts-expect-error 'Allow access to private _recoverAndRefresh'
      const session: Session | undefined = await autoRefreshClient._recoverAndRefresh()

      expect(session).toBeUndefined()
    })

    test('should handle expired session by attempting refresh', async () => {
      const { email, password } = mockUserCredentials()

      const { data: signUpData } = await autoRefreshClient.signUp({
        email,
        password,
      })
      expect(signUpData.session).not.toBeNull()

      // Manually expire the session
      const expired = new Date()
      expired.setMinutes(expired.getMinutes() - 1)
      const expiredSeconds = Math.floor(expired.getTime() / 1000)

      // @ts-expect-error 'Allow access to protected storage'
      const storage = autoRefreshClient.storage
      // @ts-expect-error 'Allow access to protected storageKey'
      const storageKey = autoRefreshClient.storageKey

      await storage.setItem(
        storageKey,
        JSON.stringify({
          ...JSON.parse((await storage.getItem(storageKey)) || 'null'),
          expires_at: expiredSeconds,
        })
      )

      // @ts-expect-error 'Allow access to private _recoverAndRefresh'
      const session: Session | null = await autoRefreshClient._recoverAndRefresh()

      expect(session).not.toBeNull()
      expect(session?.access_token).not.toBeNull()
      expect(session?.refresh_token).not.toBeNull()
      // Verify we got a new token
      expect(session?.access_token).not.toEqual(signUpData.session?.access_token)
    })

    test('does not call console.error when refresh fails with an invalid token', async () => {
      const errorSpy = jest.spyOn(console, 'error').mockImplementation(() => {})

      const storageKey = 'test-no-console-error-on-failed-refresh'
      const staleSession = {
        access_token: 'invalid-access-token',
        refresh_token: 'invalid-refresh-token',
        expires_at: Math.floor(Date.now() / 1000) - 3600,
        expires_in: 3600,
        token_type: 'bearer',
        user: null,
      }
      const storage = memoryLocalStorageAdapter({
        [storageKey]: JSON.stringify(staleSession),
      })
      const client = new GoTrueClient({
        url: GOTRUE_URL_SIGNUP_ENABLED_AUTO_CONFIRM_ON,
        autoRefreshToken: true,
        persistSession: true,
        storage,
        storageKey,
      })

      await client.getUser()

      expect(errorSpy).not.toHaveBeenCalled()
      errorSpy.mockRestore()
    })
  })

  test('should handle auto refresh start/stop multiple times', async () => {
    await autoRefreshClient.startAutoRefresh()
    await autoRefreshClient.startAutoRefresh() // Should handle duplicate calls

    await autoRefreshClient.stopAutoRefresh()
    await autoRefreshClient.stopAutoRefresh() // Should handle duplicate calls
  })
})

describe('Session Management', () => {
  test('_notifyAllSubscribers notifies all subscribers of session changes', async () => {
    const { email, password } = mockUserCredentials()
    const mockCallback = jest.fn()

    const {
      data: { subscription },
    } = authWithSession.onAuthStateChange(mockCallback)

    const { data } = await authWithSession.signUp({
      email,
      password,
    })
    expect(data.session).not.toBeNull()

    expect(mockCallback).toHaveBeenCalledWith('SIGNED_IN', data.session)

    // Cleanup
    subscription?.unsubscribe()
  })

  test('_removeSession removes session and notifies subscribers', async () => {
    const { email, password } = mockUserCredentials()
    const mockCallback = jest.fn()
    const {
      data: { subscription },
    } = authWithSession.onAuthStateChange(mockCallback)

    const { data } = await authWithSession.signUp({
      email,
      password,
    })
    expect(data.session).not.toBeNull()

    // @ts-expect-error 'Allow access to private _removeSession'
    await authWithSession._removeSession()
    expect(mockCallback).toHaveBeenCalledWith('SIGNED_OUT', null)

    const { data: sessionData } = await authWithSession.getSession()
    expect(sessionData.session).toBeNull()

    // Cleanup
    subscription?.unsubscribe()
  })

  test('should handle getSession when no session exists', async () => {
    // Clear any existing session first
    await auth.signOut()
    const { data, error } = await auth.getSession()
    expect(data.session).toBeNull()
    expect(error).toBeNull()
  })

  test('should handle refreshSession with invalid refresh token', async () => {
    const { data, error } = await auth.refreshSession({
      refresh_token: 'invalid-refresh-token',
    })

    expect(error).toBeDefined()
    expect(data.session).toBeNull()
  })

  test('should handle setSession with invalid session data', async () => {
    const { data, error } = await auth.setSession({
      access_token: 'invalid-token',
      refresh_token: 'invalid-refresh-token',
    })

    expect(error).toBeDefined()
    expect(data.session).toBeNull()
  })

  test('should handle getUser without valid session', async () => {
    await auth.signOut()
    const { data, error } = await auth.getUser()
    expect(data.user).toBeNull()
    expect(error).toBeDefined()
  })

  test('should handle updateUser without valid session', async () => {
    await auth.signOut()
    const { data, error } = await auth.updateUser({
      data: { name: 'Test User' },
    })

    expect(error).toBeDefined()
    expect(data.user).toBeNull()
  })

  test('should handle custom URL parameters', async () => {
    const client = new GoTrueClient({
      url: 'http://localhost:9999',
      detectSessionInUrl: false,
    })

    await client.initialize()
    expect(client['detectSessionInUrl']).toBe(false)
  })
})

describe('Session Management Edge Cases', () => {
  test('getSession() with invalid refreshToken should return session with invalid tokens', async () => {
    const { email, password } = mockUserCredentials()

    await authWithSession.signUp({
      email,
      password,
    })

    // Set an invalid refresh token in storage
    // @ts-expect-error 'Allow access to protected storage'
    const storage = authWithSession.storage
    // @ts-expect-error 'Allow access to protected storageKey'
    const storageKey = authWithSession.storageKey

    const invalidSession = {
      access_token: 'invalid-token',
      refresh_token: 'invalid-refresh-token',
      expires_in: 3600,
      expires_at: Math.floor(Date.now() / 1000) + 3600,
      token_type: 'bearer',
      user: null,
    }

    await storage.setItem(storageKey, JSON.stringify(invalidSession))

    const { data, error } = await authWithSession.getSession()

    expect(error).toBeNull()
    expect(data.session).not.toBeNull()
    expect(data.session).toEqual(invalidSession)
  })

  test('getSession() with expired refreshToken should return error for invalid token', async () => {
    const { email, password } = mockUserCredentials()

    const { data: signUpData } = await authWithSession.signUp({
      email,
      password,
    })

    // Manually expire the refresh token by setting it to a timestamp in the past
    const expiredSeconds = Math.floor(Date.now() / 1000) - 3600 // 1 hour in the past

    // @ts-expect-error 'Allow access to protected storage'
    const storage = authWithSession.storage
    // @ts-expect-error 'Allow access to protected storageKey'
    const storageKey = authWithSession.storageKey

    // Get the current session and modify it to be expired
    const currentSession = JSON.parse((await storage.getItem(storageKey)) || 'null')
    const expiredSession = {
      ...currentSession,
      expires_at: expiredSeconds,
      access_token: 'expired-token',
      refresh_token: 'expired-refresh-token',
    }

    await storage.setItem(storageKey, JSON.stringify(expiredSession))

    // Verify the session was properly stored
    const storedSession = JSON.parse((await storage.getItem(storageKey)) || 'null')
    expect(storedSession.expires_at).toBe(expiredSeconds)

    const { data, error } = await authWithSession.getSession()

    expect(error).not.toBeNull()
    // Error message varies between GoTrue versions
    expect(
      error?.message?.includes('Invalid Refresh Token') ||
        error?.message?.includes('Refresh token is not valid')
    ).toBe(true)
    expect(data.session).toBeNull()
  })
})

describe('Storage adapter edge cases', () => {
  test('should handle storage failure gracefully', async () => {
    const brokenStorage = {
      getItem: async () => {
        throw new Error('getItem failed message')
      },
      setItem: async () => {
        throw new Error('setItem failed message')
      },
      removeItem: async () => {
        throw new Error('removeItem failed message')
      },
    }
    const client = getClientWithSpecificStorage(brokenStorage)

    await expect(client.signOut()).rejects.toThrow('getItem failed message')
  })

  test('should handle storage getItem failure in getSession', async () => {
    const brokenStorage = {
      getItem: async () => {
        throw new Error('getItem failed message')
      },
      setItem: async () => {},
      removeItem: async () => {},
    }
    const client = getClientWithSpecificStorage(brokenStorage)
    await expect(client.getSession()).rejects.toThrow('getItem failed message')
  })

  test('should handle storage setItem failure in _saveSession', async () => {
    const brokenStorage = {
      getItem: async () => '{}',
      setItem: async () => {
        throw new Error('setItem failed message')
      },
      removeItem: async () => {},
    }
    const client = getClientWithSpecificStorage(brokenStorage)
    const session = {
      access_token: 'test-token',
      refresh_token: 'test-refresh',
      expires_in: 3600,
      token_type: 'bearer',
      user: null,
    }
    // @ts-expect-error private method
    await expect(client._saveSession(session)).rejects.toThrow('setItem failed message')

    const { data, error } = await client.getSession()
    expect(error).toBeNull()
    expect(data.session).toBeNull()
  })

  test('should preserve pending PKCE code verifier when _saveSession persists a session', async () => {
    const storage = memoryLocalStorageAdapter()
    const client = new GoTrueClient({
      url: 'http://localhost:9999',
      storageKey: 'test-pkce-preserve',
      autoRefreshToken: false,
      persistSession: true,
      storage,
      flowType: 'pkce',
    })
    const session = {
      access_token: 'test-token',
      refresh_token: 'test-refresh',
      expires_in: 3600,
      token_type: 'bearer',
      user: null,
    }

    await setItemAsync(storage, 'test-pkce-preserve-code-verifier', 'pending-verifier')

    // @ts-expect-error private method
    await client._saveSession(session)

    expect(await getItemAsync(storage, 'test-pkce-preserve-code-verifier')).toBe('pending-verifier')
  })

  test('refreshSession() should preserve pending PKCE code verifier', async () => {
    const storage = memoryLocalStorageAdapter()
    const client = new GoTrueClient({
      url: 'http://localhost:9999',
      storageKey: 'test-pkce-refresh-preserve',
      autoRefreshToken: false,
      persistSession: true,
      storage,
      flowType: 'pkce',
    })

    await setItemAsync(storage, 'test-pkce-refresh-preserve-code-verifier', 'pending-verifier')

    // @ts-expect-error access protected for test
    client._refreshAccessToken = jest.fn(async () => ({
      data: {
        session: {
          access_token: 'refreshed-token',
          refresh_token: 'refreshed-refresh-token',
          expires_in: 3600,
          expires_at: Math.floor(Date.now() / 1000) + 3600,
          token_type: 'bearer',
          user: {
            id: 'user-id',
            aud: 'authenticated',
            user_metadata: {},
            app_metadata: {},
            created_at: new Date().toISOString(),
          },
        },
        user: {
          id: 'user-id',
          aud: 'authenticated',
          user_metadata: {},
          app_metadata: {},
          created_at: new Date().toISOString(),
        },
      },
      error: null,
    }))

    const { error, data } = await client.refreshSession({ refresh_token: 'refresh-token-r1' })

    expect(error).toBeNull()
    expect(data.session?.refresh_token).toBe('refreshed-refresh-token')
    expect(await getItemAsync(storage, 'test-pkce-refresh-preserve-code-verifier')).toBe(
      'pending-verifier'
    )
  })

  test('should handle storage removeItem failure in _removeSession', async () => {
    const brokenStorage = {
      getItem: async () => '{}',
      setItem: async () => {},
      removeItem: async () => {
        throw new Error('removeItem failed message')
      },
    }
    const client = getClientWithSpecificStorage(brokenStorage)

    await expect(client.getSession()).rejects.toThrow('removeItem failed message')
  })

  test('should handle invalid JSON in storage', async () => {
    const invalidStorage = {
      getItem: async () => 'invalid-json',
      setItem: async () => {},
      removeItem: async () => {},
    }
    const client = getClientWithSpecificStorage(invalidStorage)
    const { data, error } = await client.getSession()
    expect(error).toBeNull()
    expect(data.session).toBeNull()
  })

  test('should handle null storage value', async () => {
    const nullStorage = {
      getItem: async () => null,
      setItem: async () => {},
      removeItem: async () => {},
    }
    const client = getClientWithSpecificStorage(nullStorage)
    const { data, error } = await client.getSession()
    expect(error).toBeNull()
    expect(data.session).toBeNull()
  })

  test('should handle empty storage value', async () => {
    const emptyStorage = {
      getItem: async () => '',
      setItem: async () => {},
      removeItem: async () => {},
    }
    const client = getClientWithSpecificStorage(emptyStorage)
    const { data, error } = await client.getSession()
    expect(error).toBeNull()
    expect(data.session).toBeNull()
  })

  test('should handle malformed session data', async () => {
    const malformedStorage = {
      getItem: async () => JSON.stringify({ access_token: 'test' }), // Missing required fields
      setItem: async () => {},
      removeItem: async () => {},
    }
    const client = getClientWithSpecificStorage(malformedStorage)
    const { data, error } = await client.getSession()
    expect(error).toBeNull()
    expect(data.session).toBeNull()
  })

  test('should handle expired session data', async () => {
    const expiredStorage = {
      getItem: async () =>
        JSON.stringify({
          access_token: 'test',
          refresh_token: 'test',
          expires_in: 3600,
          expires_at: Math.floor(Date.now() / 1000) - 1000, // Expired 1 second ago
          token_type: 'bearer',
          user: null,
        }),
      setItem: async () => {},
      removeItem: async () => {},
    }
    const client = getClientWithSpecificStorage(expiredStorage)
    // @ts-expect-error private method
    client._refreshAccessToken = async () => ({ data: { session: null, user: null }, error: null })
    const { data, error } = await client.getSession()

    expect(data.session).toBeNull()
    expect(error).not.toBeNull()
    expect(error?.message).toContain('Auth session missing!')
  })

  test('should return false for _isImplicitGrantCallback with missing params', () => {
    const client = getClientWithSpecificStorage(memoryLocalStorageAdapter())
    // @ts-expect-error private method
    expect(client._isImplicitGrantCallback({})).toBe(false)
    // @ts-expect-error private method
    expect(client._isImplicitGrantCallback({ foo: 'bar' })).toBe(false)
  })

  test('should return true for _isImplicitGrantCallback when auth params are present', () => {
    const client = getClientWithSpecificStorage(memoryLocalStorageAdapter())
    // @ts-expect-error private method
    expect(client._isImplicitGrantCallback({ access_token: 'token' })).toBe(true)
    // @ts-expect-error private method
    expect(client._isImplicitGrantCallback({ error: 'access_denied' })).toBe(true)
    // @ts-expect-error private method
    expect(client._isImplicitGrantCallback({ error_description: 'expired' })).toBe(true)
    // @ts-expect-error private method
    expect(client._isImplicitGrantCallback({ error_code: 'otp_expired' })).toBe(true)
  })

  test('should return false for _isPKCECallback with missing params', async () => {
    const client = getClientWithSpecificStorage(memoryLocalStorageAdapter())
    // @ts-expect-error private method
    await expect(client._isPKCECallback({})).resolves.toBe(false)
  })

  test('should build provider URL with _getUrlForProvider', async () => {
    const client = getClientWithSpecificStorage(memoryLocalStorageAdapter())
    // @ts-expect-error private method
    const url = await client._getUrlForProvider(
      GOTRUE_URL_SIGNUP_ENABLED_AUTO_CONFIRM_ON,
      'google',
      { redirectTo: 'http://localhost' }
    )
    expect(typeof url).toBe('string')
    expect(url).toContain('google')
  })

  test('_getUrlForProvider builds correct URL with PKCE flow', async () => {
    const client = new GoTrueClient({
      url: 'https://example.com',
      autoRefreshToken: false,
      persistSession: false,
      flowType: 'pkce',
    })

    const url = await client['_getUrlForProvider']('https://example.com/authorize', 'github', {
      redirectTo: 'http://localhost:3000/callback',
    })

    expect(url).toContain('provider=github')
    expect(url).toContain('code_challenge=')
    expect(url).toContain('code_challenge_method=')
  })

  test('should handle localStorage not supported', async () => {
    // Mock supportsLocalStorage to return false
    jest.doMock('../src/lib/helpers', () => ({
      ...jest.requireActual('../src/lib/helpers'),
      supportsLocalStorage: () => false,
    }))

    const client = new GoTrueClient({
      url: 'http://localhost:9999',
    })

    await client.initialize()
    // Should fall back to memory storage
    expect(client['storage']).toBeDefined()
  })
})

describe('SSO Authentication', () => {
  test('signInWithSSO with PKCE return error when SAML is disabled', async () => {
    const { data, error } = await pkceClient.signInWithSSO({
      providerId: 'valid-provider-id',
      options: {
        redirectTo: 'http://localhost:3000/callback',
        captchaToken: 'some-token',
      },
    })

    expect(error).not.toBeNull()
    expect(error?.message).toContain('SAML 2.0 is disabled')
    expect(data).toBeNull()
  })

  test('signInWithSSO should support skipBrowserRedirect option', async () => {
    // Note: In a browser environment with SAML enabled, signInWithSSO would
    // automatically redirect to the SSO provider unless skipBrowserRedirect is true.
    // This test verifies the option is accepted (actual redirect behavior cannot
    // be tested in Node.js environment)
    const { data, error } = await pkceClient.signInWithSSO({
      providerId: 'valid-provider-id',
      options: {
        redirectTo: 'http://localhost:3000/callback',
        skipBrowserRedirect: true,
      },
    })

    // SAML is disabled in test environment, so we expect an error
    expect(error).not.toBeNull()
    expect(error?.message).toContain('SAML 2.0 is disabled')
    expect(data).toBeNull()
  })

  test.each([
    {
      name: 'with empty options',
      params: {
        providerId: 'valid-provider-id',
        domain: 'valid-domain',
        options: {},
      },
    },
    {
      name: 'without params',
      params: {} as any,
    },
    {
      name: 'with minimal params',
      params: {
        providerId: 'test-provider',
        domain: 'test-domain',
      },
    },
  ])('signInWithSSO $name', async ({ params }) => {
    const { data, error } = await pkceClient.signInWithSSO(params)

    expect(error).not.toBeNull()
    expect(error?.message).toContain('SAML 2.0 is disabled')
    expect(data).toBeNull()
  })
})

describe('Lockless coordination (default) and legacy lock opt-in', () => {
  test('default path: no custom `lock` supplied, _acquireLock is not invoked', async () => {
    const client = new GoTrueClient({
      url: GOTRUE_URL_SIGNUP_ENABLED_AUTO_CONFIRM_ON,
      autoRefreshToken: false,
      persistSession: false,
    })
    // @ts-expect-error access private _acquireLock for verification
    const acquireSpy = jest.spyOn(client, '_acquireLock')

    await client.initialize()
    await client.getSession()

    // No lock supplied → lockless coordination → _acquireLock is never called
    expect(acquireSpy).not.toHaveBeenCalled()
  })

  test('legacy path: custom `lock` is invoked when supplied', async () => {
    const mockLock = jest
      .fn()
      .mockImplementation(async (name: string, timeout: number, fn: () => Promise<unknown>) =>
        fn()
      )

    const client = new GoTrueClient({
      url: GOTRUE_URL_SIGNUP_ENABLED_AUTO_CONFIRM_ON,
      lock: mockLock,
      autoRefreshToken: false,
      persistSession: false,
    })

    await client.initialize()
    await client.getSession()

    // Custom lock supplied → legacy path → mockLock IS called.
    expect(mockLock).toHaveBeenCalled()
  })

  test('`lockAcquireTimeout` option is accepted (lockless path ignores it; legacy uses it)', async () => {
    expect(
      () =>
        new GoTrueClient({
          url: GOTRUE_URL_SIGNUP_ENABLED_AUTO_CONFIRM_ON,
          autoRefreshToken: false,
          persistSession: false,
          lockAcquireTimeout: 12345,
        })
    ).not.toThrow()
  })

  test('subscriber callback may call other auth methods without deadlock', async () => {
    // Auth methods invoked from inside an onAuthStateChange callback complete
    // without re-entering a held lock, because notification is not gated by
    // one.
    const observed: string[] = []

    const {
      data: { subscription },
    } = authWithSession.onAuthStateChange(async (event) => {
      observed.push(event)
      if (event === 'INITIAL_SESSION') {
        const { data } = await authWithSession.getSession()
        observed.push(`got-session:${data.session ? 'present' : 'null'}`)
      }
    })

    // Allow the initial-session emit to flush.
    await new Promise((resolve) => setTimeout(resolve, 100))

    subscription.unsubscribe()

    expect(observed).toContain('INITIAL_SESSION')
    expect(observed.some((s) => s.startsWith('got-session:'))).toBe(true)
  })
})

describe('initializePromise deadlock fix', () => {
  // Regression tests for: getSession()/getUser() called from inside an
  // onAuthStateChange callback that fires during _recoverAndRefresh().
  // Before the fix, those methods awaited initializePromise which was still
  // pending — causing a permanent circular deadlock.

  const plantInitSession = async (
    storage: ReturnType<typeof memoryLocalStorageAdapter>,
    secondsUntilExpiry: number
  ): Promise<Session> => {
    const session: Session = {
      access_token: 'jwt.accesstoken.signature',
      refresh_token: 'refresh-token-init-test',
      token_type: 'bearer',
      expires_in: secondsUntilExpiry,
      expires_at: Math.floor(Date.now() / 1000) + secondsUntilExpiry,
      user: { id: 'user-init', email: 'init@example.com' } as any,
    }
    await setItemAsync(storage, STORAGE_KEY, session)
    return session
  }

  const noDeadlock = (promise: Promise<unknown>) =>
    Promise.race([
      promise,
      new Promise((_, reject) =>
        setTimeout(() => reject(new Error('deadlock: promise did not settle within 2s')), 2000)
      ),
    ])

  test('getSession() inside SIGNED_IN callback (valid session at init) resolves without deadlock', async () => {
    const storage = memoryLocalStorageAdapter()
    // 120s > EXPIRY_MARGIN_MS (90s): session is valid, no refresh needed.
    // _recoverAndRefresh fires SIGNED_IN synchronously — the old code path
    // that deadlocked.
    await plantInitSession(storage, 120)

    const client = new GoTrueClient({
      url: GOTRUE_URL_SIGNUP_ENABLED_AUTO_CONFIRM_ON,
      storage,
      autoRefreshToken: false,
      persistSession: true,
      skipAutoInitialize: true,
    })

    let sessionFromCallback: Session | null | undefined = undefined
    client.onAuthStateChange(async (event) => {
      if (event === 'SIGNED_IN') {
        const { data } = await client.getSession()
        sessionFromCallback = data.session
      }
    })

    await expect(noDeadlock(client.initialize())).resolves.toBeDefined()
    expect(sessionFromCallback).not.toBeUndefined()
    expect(sessionFromCallback).not.toBeNull()
  })

  test('getSession() inside TOKEN_REFRESHED callback (near-expiry session at init) resolves without deadlock', async () => {
    const storage = memoryLocalStorageAdapter()
    // 60s < EXPIRY_MARGIN_MS (90s): triggers proactive refresh during init.
    // _callRefreshToken fires TOKEN_REFRESHED — another deadlock path.
    await plantInitSession(storage, 60)

    const client = new GoTrueClient({
      url: GOTRUE_URL_SIGNUP_ENABLED_AUTO_CONFIRM_ON,
      storage,
      autoRefreshToken: true,
      persistSession: true,
      skipAutoInitialize: true,
    })

    // @ts-expect-error access protected for test
    client._refreshAccessToken = jest.fn(async () => ({
      data: {
        session: {
          access_token: 'new.access.token',
          refresh_token: 'new-refresh-token',
          token_type: 'bearer',
          expires_in: 3600,
          expires_at: Math.floor(Date.now() / 1000) + 3600,
          user: { id: 'user-init', email: 'init@example.com' } as any,
        },
      },
      error: null,
    }))

    let sessionFromCallback: Session | null | undefined = undefined
    client.onAuthStateChange(async (event) => {
      if (event === 'TOKEN_REFRESHED') {
        const { data } = await client.getSession()
        sessionFromCallback = data.session
      }
    })

    await expect(noDeadlock(client.initialize())).resolves.toBeDefined()
    expect(sessionFromCallback).not.toBeUndefined()
  })

  test('initialize() fires SIGNED_IN after initializePromise resolves (getSession works in callback)', async () => {
    const storage = memoryLocalStorageAdapter()
    await plantInitSession(storage, 120)

    const client = new GoTrueClient({
      url: GOTRUE_URL_SIGNUP_ENABLED_AUTO_CONFIRM_ON,
      storage,
      autoRefreshToken: false,
      persistSession: true,
      skipAutoInitialize: true,
    })

    // Track whether initializePromise was resolved at the time the callback ran.
    let initResolvedDuringCallback = false
    client.onAuthStateChange(async (event) => {
      if (event === 'SIGNED_IN') {
        // @ts-expect-error access protected for test
        initResolvedDuringCallback = client.initializePromise !== null
      }
    })

    await noDeadlock(client.initialize())
    // The SIGNED_IN callback ran after initializePromise was set (non-null),
    // meaning it was already resolved when the callback executed.
    expect(initResolvedDuringCallback).toBe(true)
  })
})

describe('dispose() lifecycle', () => {
  test('idempotent: safe to call repeatedly', async () => {
    const client = new GoTrueClient({
      url: GOTRUE_URL_SIGNUP_ENABLED_AUTO_CONFIRM_ON,
      autoRefreshToken: false,
      persistSession: false,
    })
    await client.initialize()

    await expect(client.dispose()).resolves.toBeUndefined()
    await expect(client.dispose()).resolves.toBeUndefined()
  })

  test('clears registered onAuthStateChange subscribers', async () => {
    const client = new GoTrueClient({
      url: GOTRUE_URL_SIGNUP_ENABLED_AUTO_CONFIRM_ON,
      autoRefreshToken: false,
      persistSession: false,
    })
    await client.initialize()

    const cb = jest.fn()
    client.onAuthStateChange(cb)

    // @ts-expect-error access protected field for verification
    expect(client.stateChangeEmitters.size).toBeGreaterThan(0)

    await client.dispose()

    // @ts-expect-error access protected field for verification
    expect(client.stateChangeEmitters.size).toBe(0)
  })

  test('stops the auto-refresh ticker', async () => {
    const client = new GoTrueClient({
      url: GOTRUE_URL_SIGNUP_ENABLED_AUTO_CONFIRM_ON,
      autoRefreshToken: true,
      persistSession: false,
    })
    await client.initialize()
    await client.startAutoRefresh()

    // @ts-expect-error access protected field for verification
    expect(client.autoRefreshTicker).not.toBeNull()

    await client.dispose()

    // @ts-expect-error access protected field for verification
    expect(client.autoRefreshTicker).toBeNull()
  })
})

describe('Refresh commit guard (signOut-during-refresh race)', () => {
  test('discards rotated tokens when storage was cleared mid-flight', async () => {
    const storage = memoryLocalStorageAdapter()
    const client = new GoTrueClient({
      url: GOTRUE_URL_SIGNUP_ENABLED_AUTO_CONFIRM_ON,
      storage,
      autoRefreshToken: false,
      persistSession: true,
    })
    await client.initialize()

    // Plant a session in storage with refresh_token R1.
    const R1 = 'refresh-token-r1'
    await setItemAsync(storage, STORAGE_KEY, {
      access_token: 'jwt.accesstoken.signature',
      refresh_token: R1,
      token_type: 'bearer',
      expires_in: 1000,
      expires_at: Math.floor(Date.now() / 1000) + 1000,
      user: { id: 'user-1', email: 'u@example.com' } as any,
    } as Session)

    // Simulate a successful refresh that returns rotated tokens (R2) while
    // storage was cleared between fetch start and continuation.
    // @ts-expect-error access protected for test
    client._refreshAccessToken = jest.fn(async () => {
      // Concurrent signOut clears storage before our refresh continuation runs.
      // @ts-expect-error access protected for test
      await client._removeSession()
      return {
        data: {
          session: {
            access_token: 'jwt.new.signature',
            refresh_token: 'refresh-token-r2',
            token_type: 'bearer',
            expires_in: 1000,
            expires_at: Math.floor(Date.now() / 1000) + 1000,
            user: { id: 'user-1', email: 'u@example.com' },
          } as any,
          user: { id: 'user-1', email: 'u@example.com' } as any,
        },
        error: null,
      } as any
    })

    // @ts-expect-error access protected for test
    const result = await client._callRefreshToken(R1)

    // Commit guard discards the rotated tokens.
    expect(result.error).not.toBeNull()
    expect((result.error as Error).name).toBe('AuthRefreshDiscardedError')

    // Storage stays cleared; rotated tokens were NOT written back.
    const stored = await storage.getItem(STORAGE_KEY)
    expect(stored).toBeNull()
  })

  test('accepts rotated tokens when storage was empty at fetch start', async () => {
    // Regression for the false-positive guard: snapshotting "current storage"
    // *after* the fetch and comparing to the input refresh_token would treat
    // empty-storage as "cleared mid-flight" and reject. That broke
    // setSession/refreshSession({ refresh_token }) for any caller supplying
    // externally-sourced tokens against empty storage (SSR cookie-handoff,
    // external-token hydration).
    const storage = memoryLocalStorageAdapter()
    const client = new GoTrueClient({
      url: GOTRUE_URL_SIGNUP_ENABLED_AUTO_CONFIRM_ON,
      storage,
      autoRefreshToken: false,
      persistSession: true,
    })
    await client.initialize()

    // Storage starts empty — no signOut ever ran.
    expect(await storage.getItem(STORAGE_KEY)).toBeNull()

    const rotatedSession = {
      access_token: 'jwt.new.signature',
      refresh_token: 'refresh-token-r2',
      token_type: 'bearer',
      expires_in: 1000,
      expires_at: Math.floor(Date.now() / 1000) + 1000,
      user: { id: 'user-1', email: 'u@example.com' },
    }

    // Refresh succeeds against externally-supplied refresh_token; doesn't
    // touch storage itself. The guard must NOT treat the still-empty
    // pre-snapshot as a mid-flight clear.
    // @ts-expect-error access protected for test
    client._refreshAccessToken = jest.fn(async () => ({
      data: { session: rotatedSession, user: rotatedSession.user },
      error: null,
    }))

    // @ts-expect-error access protected for test
    const result = await client._callRefreshToken('R-external')

    expect(result.error).toBeNull()
    expect(result.data?.refresh_token).toBe('refresh-token-r2')

    // Rotated tokens are persisted because storage wasn't cleared under us.
    // Read via `getItemAsync` to JSON-parse the stringified Session that
    // `_saveSession` wrote through `setItemAsync`.
    const stored = (await getItemAsync(storage, STORAGE_KEY)) as Session | null
    expect(stored?.refresh_token).toBe('refresh-token-r2')
  })

  test('accepts rotated tokens when storage holds a different session than the input refresh_token', async () => {
    // Covers the SSR-hydration / multi-account-switch path: storage already
    // holds session A, caller invokes setSession (or refreshSession) with an
    // externally-sourced refresh_token that doesn't match A. The guard must
    // not interpret "input token differs from stored token" as a mid-flight
    // race — nothing was modified between snapshots, so the rotated tokens
    // should persist and replace A.
    const storage = memoryLocalStorageAdapter()
    const client = new GoTrueClient({
      url: GOTRUE_URL_SIGNUP_ENABLED_AUTO_CONFIRM_ON,
      storage,
      autoRefreshToken: false,
      persistSession: true,
    })
    await client.initialize()

    // Plant session A (refresh_token RA) — represents "user already signed in".
    const RA = 'refresh-token-a'
    await setItemAsync(storage, STORAGE_KEY, {
      access_token: 'jwt.a.signature',
      refresh_token: RA,
      token_type: 'bearer',
      expires_in: 1000,
      expires_at: Math.floor(Date.now() / 1000) + 1000,
      user: { id: 'user-a', email: 'a@example.com' } as any,
    } as Session)

    // Caller hydrates a different session (refresh_token RB, e.g. from SSR cookie).
    // Mock the refresh to return rotated tokens for RB without touching storage.
    const rotatedB = {
      access_token: 'jwt.b.signature',
      refresh_token: 'refresh-token-b-rotated',
      token_type: 'bearer',
      expires_in: 1000,
      expires_at: Math.floor(Date.now() / 1000) + 1000,
      user: { id: 'user-b', email: 'b@example.com' },
    }
    // @ts-expect-error access protected for test
    client._refreshAccessToken = jest.fn(async () => ({
      data: { session: rotatedB, user: rotatedB.user },
      error: null,
    }))

    // @ts-expect-error access protected for test
    const result = await client._callRefreshToken('refresh-token-b')

    // The rotated tokens were accepted, not discarded by the commit guard.
    expect(result.error).toBeNull()
    expect(result.data?.refresh_token).toBe('refresh-token-b-rotated')

    // Storage now holds the rotated B session (replaces A).
    const stored = (await getItemAsync(storage, STORAGE_KEY)) as Session | null
    expect(stored?.refresh_token).toBe('refresh-token-b-rotated')
  })

  test('discards rotated tokens when a different session was written to storage mid-flight', async () => {
    // Stronger guard test: storage holds session A at fetch start; while the
    // refresh is in flight, *another* tab writes session B to storage; the
    // refresh result for A's token must be discarded because storage no
    // longer represents the state we were operating on.
    const storage = memoryLocalStorageAdapter()
    const client = new GoTrueClient({
      url: GOTRUE_URL_SIGNUP_ENABLED_AUTO_CONFIRM_ON,
      storage,
      autoRefreshToken: false,
      persistSession: true,
    })
    await client.initialize()

    const RA = 'refresh-token-a'
    const sessionA: Session = {
      access_token: 'jwt.a.signature',
      refresh_token: RA,
      token_type: 'bearer',
      expires_in: 1000,
      expires_at: Math.floor(Date.now() / 1000) + 1000,
      user: { id: 'user-a', email: 'a@example.com' } as any,
    }
    await setItemAsync(storage, STORAGE_KEY, sessionA)

    // Simulate another tab writing session B mid-flight.
    // @ts-expect-error access protected for test
    client._refreshAccessToken = jest.fn(async () => {
      await setItemAsync(storage, STORAGE_KEY, {
        ...sessionA,
        refresh_token: 'refresh-token-b-from-other-tab',
      })
      return {
        data: {
          session: {
            ...sessionA,
            access_token: 'jwt.a-rotated.signature',
            refresh_token: 'refresh-token-a-rotated',
          } as any,
          user: sessionA.user as any,
        },
        error: null,
      } as any
    })

    // @ts-expect-error access protected for test
    const result = await client._callRefreshToken(RA)

    expect(result.error).not.toBeNull()
    expect((result.error as Error).name).toBe('AuthRefreshDiscardedError')

    // Storage still holds B (what the other tab wrote); A's rotated tokens
    // were correctly discarded.
    const stored = (await getItemAsync(storage, STORAGE_KEY)) as Session | null
    expect(stored?.refresh_token).toBe('refresh-token-b-from-other-tab')
  })
})

describe('userNotAvailableProxy behavior', () => {
  test('should return proxy user when userStorage is set but user is not found', async () => {
    const storage = memoryLocalStorageAdapter()
    const userStorage = memoryLocalStorageAdapter()

    const client = new GoTrueClient({
      storage,
      userStorage,
    })

    await setItemAsync(storage, STORAGE_KEY, {
      access_token: 'jwt.accesstoken.signature',
      refresh_token: 'refresh-token',
      token_type: 'bearer',
      expires_in: 1000,
      expires_at: Date.now() / 1000 + 1000,
    })

    const {
      data: { session },
    } = await client.getSession()

    expect(session?.user).toBeDefined()
    expect((session?.user as any).__isUserNotAvailableProxy).toBe(true)

    expect(() => session?.user?.id).toThrow(
      '@shanutechx/auth-js: client was created with userStorage option'
    )
  })
})

describe('Branch Coverage Improvements', () => {
  describe('PKCE Flow Error Scenarios', () => {
    test('should use PKCE flow for updateUser with email when flowType is pkce and user has session', async () => {
      const { email, password } = mockUserCredentials()

      // First sign up to get a session
      await pkceClient.signUp({
        email,
        password,
      })

      const newEmail = `updated-${email}`
      const { error, data } = await pkceClient.updateUser({
        email: newEmail,
      })

      // Should trigger PKCE code challenge generation for email update
      if (error) {
        // Expected to fail due to test environment, but should have attempted PKCE flow
        expect(error).not.toBeNull()
      } else {
        expect(data.user).not.toBeNull()
      }
    })
  })

  describe('JWKS Initialization', () => {
    test('should use existing JWKS cache when available', () => {
      const storageKey = 'test-jwks-existing-' + Date.now()

      // Create a client to populate the JWKS cache
      const firstClient = new GoTrueClient({
        url: GOTRUE_URL_SIGNUP_ENABLED_AUTO_CONFIRM_ON,
        autoRefreshToken: false,
        persistSession: false,
        storageKey,
      })

      // Verify JWKS was initialized
      expect(firstClient['jwks']).toEqual({ keys: [] })
      expect(firstClient['jwks_cached_at']).toBe(Number.MIN_SAFE_INTEGER)

      // Create a second client with the same storage key
      const secondClient = new GoTrueClient({
        url: GOTRUE_URL_SIGNUP_ENABLED_AUTO_CONFIRM_ON,
        autoRefreshToken: false,
        persistSession: false,
        storageKey,
      })

      // Should use the same JWKS cache
      expect(secondClient['jwks']).toEqual(firstClient['jwks'])
      expect(secondClient['jwks_cached_at']).toBe(firstClient['jwks_cached_at'])
    })
  })

  describe('Error Handling Branches', () => {
    test('should handle _exchangeCodeForSession with network error', async () => {
      const mockFetch = jest.fn().mockRejectedValue(new Error('Network error'))

      const clientWithFailingFetch = new GoTrueClient({
        url: GOTRUE_URL_SIGNUP_ENABLED_AUTO_CONFIRM_ON,
        autoRefreshToken: false,
        persistSession: false,
        flowType: 'pkce',
        fetch: mockFetch,
      })

      // Set up storage with code verifier
      // @ts-expect-error 'Allow access to protected storage'
      const storage = clientWithFailingFetch.storage
      // @ts-expect-error 'Allow access to protected storageKey'
      const storageKey = clientWithFailingFetch.storageKey

      await storage.setItem(`${storageKey}-code-verifier`, 'mock-verifier/signin')

      // @ts-expect-error 'Allow access to private method'
      const result = await clientWithFailingFetch._exchangeCodeForSession('mock-code')

      expect(result.error).not.toBeNull()
      expect(result.data.session).toBeNull()
      expect(result.data.user).toBeNull()
    })
  })
})

describe('GoTrueClient with throwOnError option', () => {
  const store = memoryLocalStorageAdapter()
  const client = new GoTrueClient({
    url: GOTRUE_URL_SIGNUP_ENABLED_AUTO_CONFIRM_ON,
    storageKey: 'test-storage-key',
    autoRefreshToken: false,
    persistSession: true,
    storage: {
      ...store,
    },
    throwOnError: true, // test that the client throws errors
  })

  test('signUp() should throw an error when throwOnError is true', async () => {
    const { email, password } = mockUserCredentials()

    await expect(client.signUp({ email, password: '' })).rejects.toThrow()
  })

  test('signInWithPassword() should throw an error when throwOnError is true', async () => {
    const { email, password } = mockUserCredentials()

    await expect(client.signInWithPassword({ email, password: '' })).rejects.toThrow()
  })

  test('updateUser() should throw an error when throwOnError is true', async () => {
    const { email, password } = mockUserCredentials()

    await client.signUp({ email, password })

    await expect(client.updateUser({ email: 'invalid-email' })).rejects.toThrow()
  })

  test('signInWithOtp() should throw on invalid params when throwOnError is true', async () => {
    await expect(
      client.signInWithOtp({ email: 'invalid', options: { captchaToken: 'x' } })
    ).rejects.toThrow()
  })

  test('signInWithSSO() should throw on error when throwOnError is true', async () => {
    await expect(client.signInWithSSO({ domain: 'nonexistent.example.com' })).rejects.toThrow()
  })
})

describe('GoTrueClient with skipAutoInitialize option', () => {
  const store = memoryLocalStorageAdapter()

  test('should auto-initialize by default (backward compatibility)', async () => {
    // Spy on prototype before creating instance
    const initializeSpy = jest.spyOn(GoTrueClient.prototype, 'initialize')

    const client = new GoTrueClient({
      url: GOTRUE_URL_SIGNUP_ENABLED_AUTO_CONFIRM_ON,
      storageKey: 'test-auto-init-default',
      autoRefreshToken: false,
      persistSession: true,
      storage: {
        ...store,
      },
    })

    // Wait for next tick to ensure constructor completes
    await new Promise((resolve) => setTimeout(resolve, 10))

    expect(initializeSpy).toHaveBeenCalled()

    initializeSpy.mockRestore()
  })

  test('should skip auto-initialization when skipAutoInitialize is true', async () => {
    // Spy on prototype before creating instance
    const initializeSpy = jest.spyOn(GoTrueClient.prototype, 'initialize')

    const client = new GoTrueClient({
      url: GOTRUE_URL_SIGNUP_ENABLED_AUTO_CONFIRM_ON,
      storageKey: 'test-skip-auto-init',
      autoRefreshToken: false,
      persistSession: true,
      skipAutoInitialize: true, // Skip auto-initialization
      storage: {
        ...store,
      },
    })

    // Wait for next tick
    await new Promise((resolve) => setTimeout(resolve, 10))

    expect(initializeSpy).not.toHaveBeenCalled()

    initializeSpy.mockRestore()
  })

  test('should allow manual initialization after skipAutoInitialize', async () => {
    const client = new GoTrueClient({
      url: GOTRUE_URL_SIGNUP_ENABLED_AUTO_CONFIRM_ON,
      storageKey: 'test-manual-init',
      autoRefreshToken: false,
      persistSession: true,
      skipAutoInitialize: true,
      storage: {
        ...store,
      },
    })

    // Manually initialize
    await client.initialize()

    // Client should be functional
    const { data, error } = await client.getSession()
    expect(error).toBeNull()
  })

  test('should work with lazy initialization in public methods', async () => {
    const client = new GoTrueClient({
      url: GOTRUE_URL_SIGNUP_ENABLED_AUTO_CONFIRM_ON,
      storageKey: 'test-lazy-init',
      autoRefreshToken: false,
      persistSession: true,
      skipAutoInitialize: true,
      storage: {
        ...store,
      },
    })

    // Public methods should trigger lazy initialization
    const { email, password } = mockUserCredentials()
    const { data, error } = await client.signUp({ email, password })

    // Should work without explicit initialize() call
    expect(error).toBeNull()
    expect(data.user).toBeDefined()
  })
})

describe('Refresh-token lifecycle (proactive/reactive, cooldown)', () => {
  const plantSession = async (
    storage: ReturnType<typeof memoryLocalStorageAdapter>,
    overrides: { secondsUntilExpiry?: number; refreshToken?: string } = {}
  ) => {
    const secondsUntilExpiry = overrides.secondsUntilExpiry ?? 60
    const session: Session = {
      access_token: 'jwt.accesstoken.signature',
      refresh_token: overrides.refreshToken ?? 'refresh-token-r1',
      token_type: 'bearer',
      expires_in: secondsUntilExpiry,
      expires_at: Math.floor(Date.now() / 1000) + secondsUntilExpiry,
      user: { id: 'user-1', email: 'u@example.com' } as any,
    }
    await setItemAsync(storage, STORAGE_KEY, session)
    return session
  }

  const buildClient = (storage: ReturnType<typeof memoryLocalStorageAdapter>) =>
    new GoTrueClient({
      url: GOTRUE_URL_SIGNUP_ENABLED_AUTO_CONFIRM_ON,
      storage,
      autoRefreshToken: false,
      persistSession: true,
    })

  const stubInvalidGrant = (client: GoTrueClient) => {
    const spy = jest.fn(async () => ({
      data: { session: null, user: null },
      error: Object.assign(new AuthError('Invalid Refresh Token: Already Used', 400), {
        name: 'AuthApiError',
        code: 'refresh_token_already_used',
        __isAuthError: true,
      }),
    }))
    // @ts-expect-error access protected for test
    client._refreshAccessToken = spy
    return spy
  }

  const stubNetworkError = (client: GoTrueClient) => {
    const spy = jest.fn(async () => ({
      data: { session: null, user: null },
      error: Object.assign(new AuthError('Failed to fetch', 0), {
        name: 'AuthRetryableFetchError',
        __isAuthError: true,
      }),
    }))
    // @ts-expect-error access protected for test
    client._refreshAccessToken = spy
    return spy
  }

  describe('storage preservation (Fix A)', () => {
    test('non-retryable refresh failure + access token still valid → storage preserved', async () => {
      const storage = memoryLocalStorageAdapter()
      const client = buildClient(storage)
      await client.initialize()
      await plantSession(storage, { secondsUntilExpiry: 60 })
      stubInvalidGrant(client)

      // @ts-expect-error access protected for test
      const result = await client._callRefreshToken('refresh-token-r1')

      // _callRefreshToken itself returns the error so explicit callers
      // know the refresh did not actually rotate the token; caller-visible
      // preservation lives in __loadSession (see Fix B tests below).
      expect(result.data).toBeNull()
      expect((result.error as AuthError)?.code).toBe('refresh_token_already_used')

      const stored = (await getItemAsync(storage, STORAGE_KEY)) as Session | null
      expect(stored?.refresh_token).toBe('refresh-token-r1')
    })

    test('non-retryable refresh failure + access token already expired → storage cleared', async () => {
      const storage = memoryLocalStorageAdapter()
      const client = buildClient(storage)
      await client.initialize()
      await plantSession(storage, { secondsUntilExpiry: -60 })
      stubInvalidGrant(client)

      // @ts-expect-error access protected for test
      const result = await client._callRefreshToken('refresh-token-r1')

      expect(result.data).toBeNull()
      expect((result.error as AuthError)?.code).toBe('refresh_token_already_used')

      const stored = (await getItemAsync(storage, STORAGE_KEY)) as Session | null
      expect(stored).toBeNull()
    })

    test('retryable (network) refresh failure → storage preserved regardless of expiry', async () => {
      const storage = memoryLocalStorageAdapter()
      const client = buildClient(storage)
      await client.initialize()
      await plantSession(storage, { secondsUntilExpiry: -60 })
      stubNetworkError(client)

      // @ts-expect-error access protected for test
      const result = await client._callRefreshToken('refresh-token-r1')

      expect((result.error as AuthError)?.name).toBe('AuthRetryableFetchError')

      const stored = (await getItemAsync(storage, STORAGE_KEY)) as Session | null
      expect(stored?.refresh_token).toBe('refresh-token-r1')
    })
  })

  describe('caller-visible preservation in getSession (Fix B)', () => {
    test('proactive refresh failure + access token still valid → returns preserved session', async () => {
      const storage = memoryLocalStorageAdapter()
      const client = buildClient(storage)
      await client.initialize()
      // Within EXPIRY_MARGIN_MS so __loadSession triggers a refresh, but
      // the access token is still inside its real expiry window.
      await plantSession(storage, { secondsUntilExpiry: 30 })
      stubInvalidGrant(client)

      const { data, error } = await client.getSession()

      expect(error).toBeNull()
      expect(data.session).not.toBeNull()
      expect(data.session?.access_token).toBe('jwt.accesstoken.signature')
      expect(data.session?.refresh_token).toBe('refresh-token-r1')
    })

    test('reactive refresh failure (access token already expired) → returns null + error', async () => {
      const storage = memoryLocalStorageAdapter()
      const client = buildClient(storage)
      await client.initialize()
      await plantSession(storage, { secondsUntilExpiry: -60 })
      stubInvalidGrant(client)

      const { data, error } = await client.getSession()

      expect(data.session).toBeNull()
      expect((error as AuthError)?.code).toBe('refresh_token_already_used')
    })

    test('race guard: storage cleared during refresh → returns null + error', async () => {
      const storage = memoryLocalStorageAdapter()
      const client = buildClient(storage)
      await client.initialize()
      await plantSession(storage, { secondsUntilExpiry: 30 })

      // Stub refresh: simulates a concurrent signOut by wiping storage
      // mid-refresh, then returning a non-retryable error. The race guard
      // in __loadSession must catch the disappeared storage and return null.
      // @ts-expect-error access protected for test
      client._refreshAccessToken = jest.fn(async () => {
        await storage.removeItem(STORAGE_KEY)
        return {
          data: { session: null, user: null },
          error: Object.assign(new AuthError('Invalid Refresh Token', 400), {
            name: 'AuthApiError',
            code: 'refresh_token_already_used',
            __isAuthError: true,
          }),
        }
      })

      const { data, error } = await client.getSession()

      expect(data.session).toBeNull()
      expect(error).not.toBeNull()
    })
  })

  describe('explicit-caller contract (no semantic regression)', () => {
    test('refreshSession() on proactive-preserve scenario still returns error', async () => {
      const storage = memoryLocalStorageAdapter()
      const client = buildClient(storage)
      await client.initialize()
      await plantSession(storage, { secondsUntilExpiry: 60 })
      stubInvalidGrant(client)

      const { data, error } = await client.refreshSession()

      // Explicit caller asked for a *new* token; must surface the failure
      // rather than hand back the old session as if freshly minted.
      expect(data.session).toBeNull()
      expect(data.user).toBeNull()
      expect((error as AuthError)?.code).toBe('refresh_token_already_used')
    })

    test('setSession() whose refresh fails non-retryably still returns error', async () => {
      const storage = memoryLocalStorageAdapter()
      const client = buildClient(storage)
      await client.initialize()
      stubInvalidGrant(client)

      const { data, error } = await client.setSession({
        access_token: expiredAccessToken,
        refresh_token: 'refresh-token-r1',
      })

      expect(data.session).toBeNull()
      expect(error).not.toBeNull()
    })
  })

  describe('failure cooldown (Fix C)', () => {
    test('50 sequential _callRefreshToken calls during failure → exactly 1 /token', async () => {
      const storage = memoryLocalStorageAdapter()
      const client = buildClient(storage)
      await client.initialize()
      await plantSession(storage, { secondsUntilExpiry: 60 })
      const spy = stubInvalidGrant(client)

      // @ts-expect-error access protected for test
      await client._callRefreshToken('refresh-token-r1')

      for (let i = 0; i < 50; i++) {
        // @ts-expect-error access protected for test
        const result = await client._callRefreshToken('refresh-token-r1')
        expect(result.data).toBeNull()
        expect((result.error as AuthError)?.code).toBe('refresh_token_already_used')
      }
      expect(spy).toHaveBeenCalledTimes(1)
    })

    test('cooldown cleared after successful refresh', async () => {
      const storage = memoryLocalStorageAdapter()
      const client = buildClient(storage)
      await client.initialize()
      await plantSession(storage, { secondsUntilExpiry: 60 })

      // @ts-expect-error access protected for test
      client.lastRefreshFailure = {
        refreshToken: 'refresh-token-r1',
        result: {
          data: null,
          error: Object.assign(new AuthError('stale', 400), {
            name: 'AuthApiError',
            code: 'refresh_token_already_used',
            __isAuthError: true,
          }),
        } as any,
        expiresAt: Date.now() + 30_000,
      }

      const newSession = {
        access_token: 'jwt.new.signature',
        refresh_token: 'refresh-token-r2',
        token_type: 'bearer',
        expires_in: 3600,
        expires_at: Math.floor(Date.now() / 1000) + 3600,
        user: { id: 'user-1', email: 'u@example.com' },
      }
      // @ts-expect-error access protected for test
      client._refreshAccessToken = jest.fn(async () => ({
        data: { session: newSession, user: newSession.user },
        error: null,
      }))

      // First call hits the stale cooldown.
      // @ts-expect-error access protected for test
      const cached = await client._callRefreshToken('refresh-token-r1')
      expect(cached.error).not.toBeNull()

      // Clear cooldown manually and confirm a fresh refresh resets it.
      // @ts-expect-error access protected for test
      client.lastRefreshFailure = null

      // @ts-expect-error access protected for test
      const fresh = await client._callRefreshToken('refresh-token-r1')
      expect(fresh.error).toBeNull()
      expect(fresh.data?.refresh_token).toBe('refresh-token-r2')

      // @ts-expect-error access protected for test
      expect(client.lastRefreshFailure).toBeNull()
    })

    test('cooldown cleared inside _removeSession', async () => {
      const storage = memoryLocalStorageAdapter()
      const client = buildClient(storage)
      await client.initialize()
      await plantSession(storage, { secondsUntilExpiry: 60 })

      // @ts-expect-error access protected for test
      client.lastRefreshFailure = {
        refreshToken: 'refresh-token-r1',
        result: {
          data: null,
          error: Object.assign(new AuthError('x', 400), {
            name: 'AuthApiError',
            code: 'refresh_token_already_used',
            __isAuthError: true,
          }),
        } as any,
        expiresAt: Date.now() + 30_000,
      }

      // @ts-expect-error access protected for test
      await client._removeSession()

      // @ts-expect-error access protected for test
      expect(client.lastRefreshFailure).toBeNull()
    })

    // BroadcastChannel cache-clear (GoTrueClient.ts:485-492) is not unit
    // tested here: `globalThis.BroadcastChannel` is undefined in the Jest
    // node env, so the handler is never wired up. Properly testing it
    // would need a BroadcastChannel stub or jsdom, both of which are
    // out of scope for this test file. The branch is small, exercised
    // implicitly by manual multi-tab review, and any regression here
    // would only affect cross-tab cooldown invalidation (callers in the
    // failing tab still get correct behavior via the same-tab cache).

    test('cooldown expires after REFRESH_FAILURE_COOLDOWN_MS and next call fires /token', async () => {
      jest.useFakeTimers({ doNotFake: ['setImmediate'] })
      try {
        const storage = memoryLocalStorageAdapter()
        const client = buildClient(storage)
        await client.initialize()
        await plantSession(storage, { secondsUntilExpiry: 600 })
        const spy = stubInvalidGrant(client)

        // First call sets the cooldown.
        // @ts-expect-error access protected for test
        await client._callRefreshToken('refresh-token-r1')
        expect(spy).toHaveBeenCalledTimes(1)

        // Inside the cooldown — no new /token.
        // @ts-expect-error access protected for test
        await client._callRefreshToken('refresh-token-r1')
        expect(spy).toHaveBeenCalledTimes(1)

        // Advance past the cooldown.
        jest.setSystemTime(Date.now() + REFRESH_FAILURE_COOLDOWN_MS + 1000)

        // Now the cooldown has expired — next call fires /token again.
        // @ts-expect-error access protected for test
        await client._callRefreshToken('refresh-token-r1')
        expect(spy).toHaveBeenCalledTimes(2)
      } finally {
        jest.useRealTimers()
      }
    })

    test('REFRESH_FAILURE_COOLDOWN_MS is two auto-refresh ticks', () => {
      expect(REFRESH_FAILURE_COOLDOWN_MS).toBe(2 * AUTO_REFRESH_TICK_DURATION_MS)
    })

    test('cooldown is keyed by refresh token — different token bypasses the cache', async () => {
      const storage = memoryLocalStorageAdapter()
      const client = buildClient(storage)
      await client.initialize()
      await plantSession(storage, { secondsUntilExpiry: 60 })
      const spy = stubInvalidGrant(client)

      // First call fails and caches the failure under token A.
      // @ts-expect-error access protected for test
      await client._callRefreshToken('refresh-token-A')
      expect(spy).toHaveBeenCalledTimes(1)

      // A second call with the *same* token is short-circuited by the
      // cache (no new /token).
      // @ts-expect-error access protected for test
      await client._callRefreshToken('refresh-token-A')
      expect(spy).toHaveBeenCalledTimes(1)

      // A call with a *different* refresh token (e.g. picked up from a
      // sibling tab's rotation, or hydrated via setSession / refreshSession)
      // must NOT return token A's cached failure — it must attempt a fresh
      // refresh of token B. This is the regression spydon flagged.
      // @ts-expect-error access protected for test
      await client._callRefreshToken('refresh-token-B')
      expect(spy).toHaveBeenCalledTimes(2)
    })
  })

  describe('init cleanup (no double SIGNED_OUT)', () => {
    test('_recoverAndRefresh non-retryable failure emits SIGNED_OUT exactly once', async () => {
      const storage = memoryLocalStorageAdapter()
      // Plant the session BEFORE constructing the client so it's present
      // when _recoverAndRefresh runs at init time.
      await plantSession(storage, { secondsUntilExpiry: -60 })

      const client = new GoTrueClient({
        url: GOTRUE_URL_SIGNUP_ENABLED_AUTO_CONFIRM_ON,
        storage,
        autoRefreshToken: true,
        persistSession: true,
        // Without this, the constructor fires `initialize()` in the
        // background before we can stub `_refreshAccessToken` and attach
        // the listener — the test would observe 0 events because init
        // had already settled against the unstubbed method.
        skipAutoInitialize: true,
      })

      stubInvalidGrant(client)

      const events: string[] = []
      client.onAuthStateChange((event) => {
        events.push(event)
      })

      await client.initialize()

      const signedOutCount = events.filter((e) => e === 'SIGNED_OUT').length
      expect(signedOutCount).toBe(1)
    })
  })
})
