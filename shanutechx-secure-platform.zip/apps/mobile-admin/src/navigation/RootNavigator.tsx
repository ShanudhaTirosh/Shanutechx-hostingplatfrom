import React from 'react';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { SplashScreen } from '@/screens/SplashScreen';
import { LoginScreen } from '@/screens/LoginScreen';
import { ForgotPasswordScreen } from '@/screens/ForgotPasswordScreen';
import { TicketChatScreen } from '@/screens/TicketChatScreen';
import { NotificationsScreen } from '@/screens/NotificationsScreen';
import { DeploymentDetailScreen } from '@/screens/DeploymentDetailScreen';
import { PaymentsScreen } from '@/screens/PaymentsScreen';
import { MainTabNavigator } from './MainTabNavigator';
import type { RootStackParamList } from './types';

const Stack = createNativeStackNavigator<RootStackParamList>();

export function RootNavigator() {
  return (
    <Stack.Navigator screenOptions={{ headerShown: false, animation: 'slide_from_right' }}>
      <Stack.Screen name="Splash" component={SplashScreen} />
      <Stack.Screen name="Login" component={LoginScreen} />
      <Stack.Screen name="ForgotPassword" component={ForgotPasswordScreen} />
      <Stack.Screen name="Main" component={MainTabNavigator} />
      <Stack.Screen name="TicketChat" component={TicketChatScreen} options={{ animation: 'slide_from_bottom' }} />
      <Stack.Screen name="Notifications" component={NotificationsScreen} options={{ animation: 'slide_from_bottom' }} />
      <Stack.Screen name="DeploymentDetail" component={DeploymentDetailScreen} />
      <Stack.Screen name="Payments" component={PaymentsScreen} options={{ animation: 'slide_from_bottom' }} />
    </Stack.Navigator>
  );
}
